# nonparametric difference plot 


# Step 1: Compute participant-wise averages
d_indiv <- dsmall %>%
  group_by(participant, discs, adaptation, adaptcon, movdir) %>%
  summarise(mean_answer = mean(answers), .groups = "drop")

# Step 2: Compute BEFORE - AFTER difference per participant
d_diff <- d_indiv %>%
  mutate(adaptation_label = ifelse(adaptation == 0, "Before", "After")) %>%
  select(-adaptation) %>%
  pivot_wider(names_from = adaptation_label, values_from = mean_answer) %>%
  mutate(diff = Before - After)

# Step 3: Average across participants for group curves
d_avg <- d_diff %>%
  group_by(discs, adaptcon, movdir) %>%
  summarise(
    mean_diff = mean(diff),
    se = sem(diff),
    .groups = "drop"
  )

# Step 4: Add labels
label_data <- function(df) {
  df %>%
    mutate(
      movdir_label = ifelse(movdir == 0, "Rightward", "Leftward"),
      condition = factor(adaptcon, labels = c("SyncL", "SyncP", "AsyncP"))
    )
}
d_diff <- label_data(d_diff)
d_avg <- label_data(d_avg)

# Step 5: Plot
nonparametric_diff <- ggplot() +
  # Individual subject difference lines
  geom_line(
    data = d_diff,
    aes(x = discs, y = diff, group = interaction(participant, movdir_label)),
    color = "gray85",
    size = 0.7,
    alpha = 0.5
  ) +
  # Group mean difference lines with points
  geom_line(
    data = d_avg,
    aes(x = discs, y = mean_diff, linetype = movdir_label, group = movdir_label),
    color = "#1f78b4",
    size = 1
  ) +
  geom_point(
    data = d_avg,
    aes(x = discs, y = mean_diff, shape = movdir_label),
    color = "#1f78b4",
    size = 2
  ) +
  geom_errorbar(
    data = d_avg,
    aes(x = discs, ymin = mean_diff - se, ymax = mean_diff + se),
    width = 0.03,
    color = "#1f78b4"
  ) + 
  facet_wrap(~ condition) +
  labs(
    x = "Disc Overlap",
    y = "Adaptation Effect",
    linetype = "Movement Direction",
    shape = "Movement Direction"
  ) +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "bottom",
    strip.text = element_text(face = "bold", size = 14),
    panel.grid.minor = element_blank()
  )

# Show plot
print(nonparametric_diff)

# save_plot(nonparametric_diff, "non_parametric_diff.png", path_figures)
