# my colour palette

my_colors <- c(
  "pre"  = "#2a9d8f",
  "post"  = "#ff7d00",
  
  "SyncL" = "#1f78b4",
  "SyncP" = "#ff7d00",
  "ASyncP" = "#2a9d8f", 
  
  "incongruent" = "#2a9d8f", 
  "congruent" = "#ff7d00"
  )
