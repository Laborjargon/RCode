# Hi vs Lo Subset 
# this is the low group
# 12 plots 6 hi group & 6 lo group


low_list <- as.numeric(as.character(unique(all_data_split$person[which(all_data_split$median_group == "low")])))

dsmall_low <- dsmall %>%
  filter(participant %in% low_list)

fit_low <- quickpsy(dsmall_low,discs,answers,guess=TRUE,lapses=TRUE,prob=0.5,grouping = .("conditionlong","participant"), fun=logistic_fun2,parini=list(c(1,15),c(-40,-1),c(0,0.3),c(0,0.75)), bootstrap = "none")

xvals <- seq(0, 1, length.out = 100)


params_wide_low <- fit_low$par %>%
  pivot_wider(names_from = parn, values_from = par)%>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  filter(participant %in% low_list)

predicted_curves_low <- params_wide_low %>%
  rowwise() %>%
  mutate(
    x = list(xvals),
    y = list(p3 + (1-p3-p4)*logistic_fun2(x, c(p1, p2)))
  ) %>%
  unnest(c(x, y))

# label this shit

predicted_curves_low$adaptation <- factor(predicted_curves_low$adaptation, levels = c("pre", "post"))

predicted_curves_low$movdir <- factor(predicted_curves_low$movdir,
                                     levels = c("left", "right"),
                                     labels = c("incongruent", "congruent"))

predicted_curves_low$movdir <- factor(predicted_curves_low$movdir, levels = c("congruent", "incongruent"))

# mean  curves

mean_curves_low <- predicted_curves_low %>%
  group_by(adaptcon, movdir, adaptation, x) %>%
  summarise(y = mean(y), .groups = 'drop')


# add PSEs ----------------------------------------------------------------

PSE_table_low <- fit_low$thresholds %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  rename(x = thre, y = prob) %>%
  filter(participant %in% low_list)

PSE_table_low$adaptation <- factor(PSE_table_low$adaptation, levels = c("pre", "post"))

PSE_table_low$movdir <- factor(PSE_table_low$movdir,
                              levels = c("left", "right"),
                              labels = c("incongruent", "congruent"))

PSE_table_low$movdir <- factor(PSE_table_low$movdir, levels = c("congruent", "incongruent"))

PSE_means_low <- mean_curves_low %>%
  group_by(adaptcon, movdir, adaptation) %>%
  slice_min(abs(y - 0.5), n = 1, with_ties = FALSE) %>%
  ungroup()

PSE_means_low$y <- 0.5

# add unfitted means ------------------------------------------------------

unfitted_means_low <- dsmall_low %>%
  filter(participant %in% low_list) %>%
  group_by(conditionlong, discs) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  summarise(y = mean(answers), .groups = "drop") %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  rename(x = discs)

unfitted_means_low$adaptation <- factor(unfitted_means_low$adaptation, levels = c("pre", "post"))

unfitted_means_low$movdir <- factor(unfitted_means_low$movdir,
                                   levels = c("left", "right"),
                                   labels = c("incongruent", "congruent"))
# CM CI 

cm_long_low$adaptation <- factor(cm_long_low$adaptation, levels = c("pre", "post"))

cm_long_low$movdir <- factor(cm_long_low$movdir,
                         levels = c("left", "right"),
                         labels = c("incongruent", "congruent"))

unfitted_means_low <- cbind(unfitted_means_low, cm_long_low[, c("ci_low", "ci_upp")]) 

PSE_means_low$adaptcon <- factor(PSE_means_low$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
unfitted_means_low$adaptcon <- factor(unfitted_means_low$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
mean_curves_low$adaptcon <- factor(mean_curves_low$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))


# psychometric plot -------------------------------------------------------
# change who is in the data according to median groups

psychometric_plot_low <- ggplot(mean_curves_low, aes(x = x, y = y, color = adaptation)) +
  geom_point(data = unfitted_means_low, aes(x = x, y = y, color = adaptation), shape = 20, size = 2, inherit.aes = FALSE)+
  geom_errorbar(data = unfitted_means_low,
                aes(x = x, ymin = ci_low, ymax = ci_upp, color = adaptation),
                width = 0,
                linewidth = 0.5,
                inherit.aes = FALSE) +
  geom_line(linewidth = 1) +
  facet_grid(movdir ~ adaptcon) +
  labs(
    x = "Disc Overlap",
    y = "Causal Report",
    color = "Adaptation"
  ) +
  geom_point(data = PSE_means_low, aes(x = x, y = y, fill = adaptation), shape = 21, size = 3, stroke = 1.5, color = "black", inherit.aes = FALSE) +
  facet_grid((movdir ~ adaptcon)) +
  theme_minimal() +
  theme(
    strip.text = element_text(face = "bold"),
    legend.position = "bottom"
  ) + 
  guides(fill = "none",
         color = "none")


# print(psychometric_plot_low)

combined_plot_HiLo <- psychometric_plot_hi + psychometric_plot_low +
  plot_layout(ncol = 2)

print(combined_plot_HiLo)

# save_plot(combined_plot_HiLo, "Median Split Curves.png", path_figures)
