# psychometric functions plotting 

# Ausgangspunkt: fit 

xvals <- seq(0, 1, length.out = 100)

params_wide <- fit$par %>%
  pivot_wider(names_from = parn, values_from = par)%>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor))

predicted_curves <- params_wide %>%
  rowwise() %>%
  mutate(
    x = list(xvals),
    y = list(p3 + (1-p3-p4)*logistic_fun2(x, c(p1, p2)))
  ) %>%
  unnest(c(x, y))

# label this shit

predicted_curves$adaptation <- factor(predicted_curves$adaptation, levels = c("pre", "post"))

predicted_curves$movdir <- factor(predicted_curves$movdir,
                             levels = c("left", "right"),
                             labels = c("incongruent", "congruent"))

predicted_curves$movdir <- factor(predicted_curves$movdir, levels = c("congruent", "incongruent"))

# mean  curves

mean_curves <- predicted_curves %>%
  group_by(adaptcon, movdir, adaptation, x) %>%
  summarise(y = mean(y), .groups = 'drop')


# add PSEs ----------------------------------------------------------------

PSE_table <- fit$thresholds %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  rename(x = thre, y = prob)

PSE_table$adaptation <- factor(PSE_table$adaptation, levels = c("pre", "post"))

PSE_table$movdir <- factor(PSE_table$movdir,
                           levels = c("left", "right"),
                           labels = c("incongruent", "congruent"))

PSE_table$movdir <- factor(PSE_table$movdir, levels = c("congruent", "incongruent"))
# TRUE PSEs! 
# PSE_means <- PSE_table %>%
#   group_by(adaptcon, movdir, adaptation, y) %>%
#   summarise(x = mean(x), .groups = 'drop')

PSE_means <- mean_curves %>%
  group_by(adaptcon, movdir, adaptation) %>%
  slice_min(abs(y - 0.5), n = 1, with_ties = FALSE) %>%
  ungroup()

PSE_means$y <- 0.5
  
# add unfitted means ------------------------------------------------------

unfitted_means <- dsmall %>%
  group_by(conditionlong, discs) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  summarise(y = mean(answers), .groups = "drop") %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  rename(x = discs)

unfitted_means$adaptation <- factor(unfitted_means$adaptation, levels = c("pre", "post"))

unfitted_means$movdir <- factor(unfitted_means$movdir,
                           levels = c("left", "right"),
                           labels = c("incongruent", "congruent"))
# CM CI 

cm_long$adaptation <- factor(cm_long$adaptation, levels = c("pre", "post"))

cm_long$movdir <- factor(cm_long$movdir,
                                levels = c("left", "right"),
                                labels = c("incongruent", "congruent"))

unfitted_means <- cbind(unfitted_means, cm_long[, c("ci_low", "ci_upp")]) 

PSE_means$adaptcon <- factor(PSE_means$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
unfitted_means$adaptcon <- factor(unfitted_means$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
mean_curves$adaptcon <- factor(mean_curves$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
  

# psychometric plot -------------------------------------------------------

psychometric_plot <- ggplot(mean_curves, aes(x = x, y = y, color = adaptation)) +
  geom_point(data = unfitted_means, aes(x = x, y = y, color = adaptation), 
             shape = 20, size = 2, inherit.aes = FALSE) +
  geom_errorbar(data = unfitted_means,
                aes(x = x, ymin = ci_low, ymax = ci_upp, color = adaptation),
                width = 0,
                linewidth = 0.5,
                inherit.aes = FALSE) +
  geom_line(linewidth = 1) +
  facet_grid(movdir ~ adaptcon) +
  labs(
    x = "Disc Overlap",
    y = "Causal Report",
    color = "Adaptation"
  ) +
  geom_point(data = PSE_means, aes(x = x, y = y, fill = adaptation), 
             shape = 21, size = 3, stroke = 1.5, color = "black", inherit.aes = FALSE) +
  scale_color_manual(values = my_colors) +
  scale_fill_manual(values = my_colors) +
  theme_minimal() +
  theme(
    strip.text = element_text(face = "bold"),
    legend.position = "bottom"
  ) +
  guides(fill = "none", color = "none")

print(psychometric_plot)

# save_plot(psychometric_plot, "Psychometric Plot.png", path_figures)




