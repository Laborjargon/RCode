# IMP stats 

all_data_split$person <- as.factor(all_data_split$person)
all_data_split$movdir <- as.factor(all_data_split$movdir)
all_data_split$condition <- as.factor(all_data_split$condition)
all_data_split$median_group <- as.factor(all_data_split$median_group)
all_data_split$session <- as.factor(all_data_split$session)

IMP_ANOVA <- ezANOVA(
  data = all_data_split,
  dv = coolness,
  wid = person,
  within = .(movdir, condition, session),
  between = .(median_group),
  detailed = TRUE,
  type = 3
)

print(IMP_ANOVA)

# | Effect                            | F       | p-value          | Significant? | Effect size (ges) | Interpretation                                                                 |
#   |----------------------------------|---------|------------------|--------------|-------------------|--------------------------------------------------------------------------------|
#   | **(Intercept)**                  | 4886.85 | ***<0.000001***  | **✓**        | 0.940             | Baseline coolness far from zero; expected.                                     |
#   | **median_group**                 | 36.98   | ***0.000118***   | **✓**        | 0.106             | Strong between-group difference; median groups differ in coolness.            |
#   | **movdir**                       | 0.29    | 0.599            | ✗            | 0.0004            | No main effect of motion direction.                                            |
#   | **condition**                    | 87.92   | ***<0.000001***  | **✓**        | 0.824             | Huge main effect; condition strongly affects coolness.                         |
#   | **session**                      | 0.11    | 0.742            | ✗            | 0.0003            | No main effect of session.                                                     |
#   | **median_group × movdir**        | 0.009   | 0.926            | ✗            | 0.00001           | No interaction between group and motion direction.                             |
#   | **median_group × condition**     | 4.49    | **0.0043**       | **✓**        | 0.193             | Significant interaction; group differences depend on condition.                |
#   | **median_group × session**       | 0.35    | 0.565            | ✗            | 0.001             | No interaction between group and session.                                      |
#   | **movdir × condition**           | 1.56    | 0.205            | ✗            | 0.011             | No interaction between motion direction and condition.                         |
#   | **movdir × session**             | 0.0008  | 0.978            | ✗            | 0.000002          | No interaction between motion direction and session.                           |
#   | **condition × session**          | 0.45    | 0.774            | ✗            | 0.009             | No interaction between condition and session.                                  |
#   | **group × movdir × condition**   | 2.09    | 0.101            | ✗            | 0.014             | Trend-level 3-way interaction; not significant.                                |
#   | **group × movdir × session**     | 0.26    | 0.621            | ✗            | 0.0006            | No 3-way interaction involving group, movdir, and session.                     |
#   | **group × condition × session**  | 1.35    | 0.268            | ✗            | 0.028             | No 3-way interaction involving group, condition, and session.                  |
#   | **movdir × condition × session** | 1.97    | 0.117            | ✗            | 0.016             | No 3-way interaction between movdir, condition, and session.                   |
#   | **4-way interaction**            | 1.58    | 0.199            | ✗            | 0.013             | No significant 4-way interaction.                                              |


imp_means <- all_data_split %>%
  group_by(condition, person) %>%
  summarise(coolness = mean(coolness, na.rm = TRUE), .groups = 'drop')

t.test(imp_means$coolness[which(imp_means$condition=="syncP")],
       imp_means$coolness[which(imp_means$condition=="Pass")],
       paired=TRUE)


                             