
# Step 1: Compute participant-wise averages

d_indiv <- dsmall %>%
  group_by(participant, discs, adaptation, movdir, adaptcon) %>%
  summarise(
  mean_answer = mean(answers),
  se_answer = sd(answers),
  .groups = "drop"
  )


# Step 2: Compute group averages
d_avg <- d_indiv %>%
  group_by(discs, adaptation, movdir, adaptcon) %>%
  summarise(
    mean_answer = mean(mean_answer),
    mean_se = mean(se_answer),
    .groups = "drop"
  )

# Step 3: Add labels
label_data <- function(df) {
  df %>%
    mutate(
      adaptation_label = ifelse(adaptation == 0, "Before", "After"),
      movdir_label = ifelse(movdir == 0, "Rightward", "Leftward"),
      condition = factor(adaptcon, labels = c("SyncL", "SyncP", "AsyncP"))
    )
}
d_indiv <- label_data(d_indiv)
d_avg <- label_data(d_avg)

# Step 4: Plot
nonparametric <- ggplot() +
  # Individual subject lines
  geom_line(
    data = d_indiv,
    aes(x = discs, y = mean_answer, group = interaction(participant, adaptation_label, movdir_label)),
    color = "gray85",
    size = 0.7,
    alpha = 0.5
  ) +
  # Group averages with points
  geom_line(
    data = d_avg,
    aes(x = discs, y = mean_answer, color = adaptation_label, linetype = movdir_label, group = interaction(adaptation_label, movdir_label)),
    size = 1
  ) +
  geom_point(
    data = d_avg,
    aes(x = discs, y = mean_answer, color = adaptation_label, shape = movdir_label),
    size = 2
  ) +
  geom_errorbar(
    data = d_avg,
    aes(x = discs, ymin = mean_answer - (mean_se/2), ymax = mean_answer + (mean_se/2),
        color = adaptation_label),
    width = 0.03
  ) + 
  facet_wrap(~ condition) +
  labs(
    x = "Disc Overlap",
    y = "Mean Answer",
    color = "Adaptation",
    linetype = "Movement Direction",
    shape = "Movement Direction"
  ) +
  scale_color_manual(values = c("Before" = "#1f78b4", "After" = "#e31a1c")) +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "bottom",
    strip.text = element_text(face = "bold", size = 14),
    panel.grid.minor = element_blank()
  )

print(nonparametric)

# save_plot()
