# median split CM CI; weird requirements deswegen new file 
# HI / LOW CM CI  ---------------------------------------------------------

hi_list <- as.numeric(as.character(unique(all_data_split$person[which(all_data_split$median_group == "high")])))

dsmall_hi <- dsmall %>%
  filter(participant %in% hi_list)

participant_means_hi <- dsmall_hi %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  group_by(participant, conditionlong, discs) %>%
  summarise(y = mean(answers), .groups = "drop") %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  rename(x = discs)

wide_df_hi <- participant_means_hi %>%
  mutate(cond_id = paste(movdir, adaptation, adaptcon, x, sep = "_")) %>%
  select(participant, cond_id, y) %>%
  pivot_wider(names_from = cond_id, values_from = y)

ci_data_hi <- wide_df_hi %>% select(-participant)

ci_results_hi <- ci.mean.w(ci_data_hi, conf.level = 2*(pnorm(1.00,0,1)-0.5)) # this is where the magic happens; adjust conf.level

# Access lower and upper bounds
ci_bounds_hi <- ci_results_hi[["result"]][, c("low", "upp")]

# Add means back in
means <- ci_results_hi[["result"]][, "m"]
cond_names <- colnames(ci_data_hi)

ci_df_hi <- data.frame(
  condition = cond_names,
  mean = means,
  ci_low = ci_bounds_hi$low,
  ci_upp = ci_bounds_hi$upp
)

cm_long_hi <- ci_df_hi %>%
  separate(condition, into = c("movdir", "adaptation", "adaptcon", "x"), sep = "_") %>%
  mutate(x = as.numeric(x))

# brilliant solution for low  ---------------------------------------------
low_list <- as.numeric(as.character(unique(all_data_split$person[which(all_data_split$median_group == "low")])))

dsmall_low <- dsmall %>%
  filter(participant %in% low_list)

participant_means_low <- dsmall_low %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  group_by(participant, conditionlong, discs) %>%
  summarise(y = mean(answers), .groups = "drop") %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  rename(x = discs)

wide_df_low <- participant_means_low %>%
  mutate(cond_id = paste(movdir, adaptation, adaptcon, x, sep = "_")) %>%
  select(participant, cond_id, y) %>%
  pivot_wider(names_from = cond_id, values_from = y)

ci_data_low <- wide_df_low %>% select(-participant)

ci_results_low <- ci.mean.w(ci_data_low, conf.level = 2*(pnorm(1.00,0,1)-0.5)) # this is where the magic happens; adjust conf.level

# Access lower and upper bounds
ci_bounds_low <- ci_results_low[["result"]][, c("low", "upp")]

# Add means back in
means <- ci_results_low[["result"]][, "m"]
cond_names <- colnames(ci_data_low)

ci_df_low <- data.frame(
  condition = cond_names,
  mean = means,
  ci_low = ci_bounds_low$low,
  ci_upp = ci_bounds_low$upp
)

cm_long_low <- ci_df_low %>%
  separate(condition, into = c("movdir", "adaptation", "adaptcon", "x"), sep = "_") %>%
  mutate(x = as.numeric(x))
