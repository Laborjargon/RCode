# load data

# List all .dat files in the directory
dat_files <- list.files(path_data, pattern = "\\.dat$", full.names = TRUE)

# Helper function to extract participant and session from filename
extract_ids <- function(filename) {
  base <- tools::file_path_sans_ext(basename(filename))
  # Match "Coc" followed by digits, last digit is session, rest is participant
  match <- regmatches(base, regexec("^Coc3(\\d+)$", base))[[1]]
  code <- match[2]
  len <- nchar(code)
  list(
    participant = as.integer(substr(code, 1, len - 1)),
    session = as.integer(substr(code, len, len))
  )
}
# Load files into a list with participant/session info
data_list <- lapply(dat_files, function(file) {
  ids <- extract_ids(file)
  data <- read.table(file, header = FALSE)  # adjust if not tabular or not headered
  attr(data, "participant") <- ids$participant
  attr(data, "session") <- ids$session
  data
})

# Optional: create a data frame with all data and participant/session columns
combined_data <- bind_rows(lapply(data_list, function(df) {
  df %>%
    mutate(participant = attr(df, "participant"),
           session = attr(df, "session"))
}))
