# cumulative sum plot with CM CI 

plot_data <- data.frame(
  condition = colnames(ci_data_input),
  mean_diff = ci_results_summary[["result"]][, "m"],
  ci_low = ci_results_summary[["result"]][, "low"],
  ci_upp = ci_results_summary[["result"]][, "upp"]
) %>%
  separate(condition, into = c("movdir", "adaptcon"), sep = "_", extra = "merge")

plot_data$adaptcon <- factor(plot_data$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
plot_data$movdir <- factor(plot_data$movdir, levels = c("congruent", "incongruent"))

sum_adapt <- ggplot(plot_data, aes(x = adaptcon, y = mean_diff, fill = movdir)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  geom_errorbar(
    aes(ymin = ci_low, ymax = ci_upp), # These CIs now correctly match the bar heights
    width = 0,
    size = 1, 
    position = position_dodge(width = 0.9),
    color = "black") +
  labs(
    title = "Magnitude of Adaptation",
    x = "Adaptation Condition",
    y = "Cumulative Adaptation [diam.]",
    fill = "Motion Direction"
  ) +
  scale_fill_manual(values = my_colors) +
  theme_minimal()

print(sum_adapt)

# save_plot(sum_adapt, "Cumulative Adaptation.png", path_figures)
