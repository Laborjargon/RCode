# adaptation difference plot 


# Step 1: Compute participant-wise averages
d_indiv <- dsmall %>%
  group_by(participant, discs, adaptation, adaptcon, movdir) %>%
  summarise(mean_answer = mean(answers), .groups = "drop")

# Step 2: Compute BEFORE - AFTER difference per participant
d_diff <- d_indiv %>%
  mutate(adaptation_label = ifelse(adaptation == 0, "Pre", "Post")) %>%
  select(-adaptation) %>%
  pivot_wider(names_from = adaptation_label, values_from = mean_answer) %>%
  mutate(diff = Post - Pre)

# Step 3: Average across participants for group curves
d_avg <- d_diff %>%
  group_by(discs, adaptcon, movdir) %>%
  summarise(
    mean_diff = mean(diff),
    #se = sem(diff),
    .groups = "drop"
  )%>%
  rename(x = discs)

# Step 4: Add labels
label_data <- function(df) {
  df %>%
    mutate(
      movdir = ifelse(movdir == 0, "congruent", "incongruent"),
      adaptcon = factor(adaptcon, labels = c("SyncL", "SyncP", "ASyncP"))
    )
}
d_diff <- label_data(d_diff)
d_avg <- label_data(d_avg)

d_avg <- d_avg %>%
  left_join(
    ci_diff_df %>% select(movdir, adaptcon, x, ci_low, ci_upp),
    by = c("movdir", "adaptcon", "x")
  )


# create polygons for shading ---------------------------------------------

poly_data <- d_avg %>%
  arrange(adaptcon, movdir, x) %>%
  group_by(adaptcon, movdir) %>%
  do({
    df <- .
    data.frame(
      adaptcon = df$adaptcon[1],
      movdir   = df$movdir[1],
      x = c(df$x, rev(df$x)),                 # forward then back
      y = c(df$mean_diff, rep(0, nrow(df)))   # curve then baseline
    )
  }) %>%
  ungroup()
poly_data$movdir <- as.factor(poly_data$movdir)

# Plot --------------------------------------------------------------------

shade_colours <- c("congruent"  = "#bde0fe",
                   "incongruent"  = "#a2d2ff")

adaptation_difference <- ggplot() +
  geom_polygon(
    data = poly_data,
    aes(x = x, y = y, group = interaction(adaptcon, movdir), fill = movdir),
    alpha = 0.35
  ) +
  scale_fill_manual(values = shade_colours) + 
  # Group mean difference lines with points
  geom_line(
    data = d_avg,
    aes(x = x, y = mean_diff, linetype = movdir, group = movdir),
    color = "#1f78b4",
    size = 1
  ) +
  geom_point(
    data = d_avg,
    aes(x = x, y = mean_diff, shape = movdir),
    color = "#1f78b4",
    size = 3
  ) +
  geom_errorbar(
    data = d_avg,
    aes(x = x, ymin = ci_low, ymax = ci_upp),
    width = 0,
    size = 1,
    color = "#1f78b4"
  ) +
  facet_wrap(~ adaptcon) +
  labs(
    x = "Disc Overlap",
    y = "Adaptation Effect",
    linetype = "Movement Direction",
    shape = "Movement Direction"
  ) +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "bottom",
    strip.text = element_text(face = "bold", size = 14),
    panel.grid.minor = element_blank()
  ) + 
  guides(fill = "none")


print(adaptation_difference)

# save_plot(adaptation_difference, "adaptation_difference.png", path_figures)
