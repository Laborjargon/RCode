# stats 
# this is where I run all the anovas and such to quantify my effects

PSE_table

PSE_table$mcat <- as.factor(PSE_table$mcat)

PSE_ANOVA <- ezANOVA(
  data = PSE_table,
  dv = thre,
  wid = participant,
  within = .(movdir, adaptcon, adaptation),
  between = .(mcat),
  detailed = TRUE,
  type = 3
)


print(PSE_ANOVA)

# | Effect         | F     | p-value         | Significant? | Effect size (ges) | Interpretation                                        |
#   | -------------- | ----- | --------------- | ------------ | ----------------- | ----------------------------------------------------- |
#   | **mcat**       | 0.094 | 0.765           | ✗            | 0.005             | No between-subjects difference based on median split. |
#   | **movdir**     | 0.448 | 0.518           | ✗            | 0.008             | No main effect of motion direction.                   |
#   | **adaptcon**   | 57.93 | ***<0.000001*** | **✓**        | 0.236             | Strong main effect of adaptation context.             |
#   | **adaptation** | 3.85  | 0.078           | ✗ (trend)    | 0.042             | Trend toward significance; worth exploring further.   |

#   | Interaction               | F     | p-value            | Significant? | Interpretation                                                     |
# | ------------------------- | ----- | ------------------ | ------------ | ------------------------------------------------------------------ |
#   | mcat × movdir             | 0.441 | 0.522              | ✗            | No interaction between group and motion direction.                 |
#   | mcat × adaptcon           | 1.94  | 0.169              | ✗            | No interaction with adaptation context.                            |
#   | mcat × adaptation         | 1.58  | 0.237              | ✗            | No interaction with adaptation.                                    |
#   | movdir × adaptcon         | 1.14  | 0.340              | ✗            | No interaction.                                                    |
#   | movdir × adaptation       | 0.105 | 0.753              | ✗            | No interaction.                                                    |
#   | **adaptcon × adaptation** | 84.53 | ***<0.000000001*** | **✓**        | Very strong interaction – effect of adaptation depends on context. |
#   
# | Higher-Order Interactions                           | F     | p-value        | Significant? | Interpretation                                                                          |
#   | ------------------------------------- | ----- | -------------- | ------------ | --------------------------------------------------------------------------------------- |
#   | mcat × movdir × adaptcon              | 0.496 | 0.616          | ✗            | Not significant.                                                                        |
#   | mcat × movdir × adaptation            | 0.009 | 0.925          | ✗            | Completely negligible.                                                                  |
#   | **mcat × adaptcon × adaptation**      | 6.69  | **0.006**      | **✓**        | Significant 3-way interaction. Group moderates the adaptcon × adaptation effect.        |
#   | **movdir × adaptcon × adaptation**    | 21.44 | ***<0.00002*** | **✓**        | Strong 3-way interaction. Motion direction also modulates adaptcon × adaptation effect. |
#   | mcat × movdir × adaptcon × adaptation | 1.63  | 0.221          | ✗            | No 4-way interaction.                                                                   |
#   

# post-hoc tests ----------------------------------------------------------


t.test(
  PSE_table$thre[which(PSE_table$adaptcon=="SyncL")], # this only really makes sense for the dPSE 
)


t.test(PSE_table$thre[which(PSE_table$adaptcon=="ASyncP")],
       PSE_table$thre[which(PSE_table$adaptcon=="SyncP")],
       paired=TRUE)
# t = 0.17769, df = 47, p-value = 0.8597 -> not significant 



