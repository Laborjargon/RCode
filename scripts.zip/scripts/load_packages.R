# load packages 

library(dplyr) # Data manipulation and transformation

library(ggplot2) # Create plots and visualisations

library(ez) # Simplify ANOVA and repeated-measures analysis

library(tidyr) # Tidy and reshape data, maybe some overlap with dplyr? 

library(quickpsy) # Fit psychometric functions

#library(superb) # Create superb plots with confidence intervals (CM CI)  

library(inflection) # Find inflection points in curves

library(misty) # Cousineau Morey and other confidence intervals 

library(patchwork) # stitch plots together
