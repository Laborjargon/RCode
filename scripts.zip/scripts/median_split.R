# median split plots; needs to run after Impnalysis but before I change PSE_table in pmf_plot
# take people who "adapted" in sync pass vs. people who didn't adapt in sync pass 
# TODO Split Plots for movdir 
# low group id's

top <- split_who %>%
  slice_max(order_by = avg_syncP, n = 6)


bottom <- split_who %>%
  slice_min(order_by = avg_syncP, n = 6)

top$person <- as.numeric(top$person)
bottom$person <- as.numeric(bottom$person)

PSE_top <- PSE_table %>%
  filter(participant %in% top$person)

PSE_bottom <- PSE_table %>%
  filter(participant %in% bottom$person)


PSE_top$adaptation <- factor(PSE_top$adaptation, levels = c("pre", "post"))

PSE_top$movdir <- factor(PSE_top$movdir,
                           levels = c("left", "right"),
                           labels = c("incongruent", "congruent"))

# TOP HALF ----------------------------------------------------------------

top_plot <- ggplot(PSE_top, aes(x = adaptation, y = x, color = adaptation)) +
  #geom_boxplot(outlier.shape = NA, alpha = 0.2, width = 0.4) +
  geom_jitter(width = 0.2, height = 0, size = 2, alpha = 0.8) +
  #stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.1, linewidth = 0.9) +
  stat_summary(fun = mean, geom = "point", shape = 21, size = 4, colour = "black", aes(fill = adaptation)) +
  facet_grid(movdir ~ adaptcon) +
  theme_minimal() +
  labs(
    title = "Top Half",
    y = "PSE"
  ) +
  theme(
    strip.text = element_text(size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )

print(top_plot)

# save_plot(PSE_plot, "PSE_plot.png", path_figures)


# BOTTOM HALF -------------------------------------------------------------


PSE_bottom$adaptation <- factor(PSE_bottom$adaptation, levels = c("pre", "post"))

PSE_bottom$movdir <- factor(PSE_bottom$movdir,
                         levels = c("left", "right"),
                         labels = c("incongruent", "congruent"))

bottom_plot <- ggplot(PSE_bottom, aes(x = adaptation, y = x, color = adaptation)) +
  #geom_boxplot(outlier.shape = NA, alpha = 0.2, width = 0.4) +
  geom_jitter(width = 0.2, height = 0, size = 2, alpha = 0.8) +
  #stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.1, linewidth = 0.9) +
  stat_summary(fun = mean, geom = "point", shape = 21, size = 4, colour = "black", aes(fill = adaptation)) +
  facet_grid(movdir ~ adaptcon) +
  theme_minimal() +
  labs(
    title = "Bottom Half",
    y = "PSE"
  ) +
  theme(
    strip.text = element_text(size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )

print(bottom_plot)

# save_plot(PSE_plot, "PSE_plot.png", path_figures)


# Difference between median groups ----------------------------------------

PSE_table <- PSE_table %>%
  mutate(mcat = ifelse(participant %in% top$person, 1, 0))

PSE_diff <- PSE_table %>%
  group_by(conditionlong, mcat) %>%
  summarise(mean_PSE = mean(x), .groups = "drop") %>%
  pivot_wider(names_from = mcat, values_from = mean_PSE, names_prefix = "mcat_") %>%
  mutate(PSE_diff = mcat_1 - mcat_0)

PSE_diff <- PSE_diff %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor))

PSE_diff$adaptation <- factor(PSE_diff$adaptation, levels = c("pre", "post"))

PSE_diff$movdir <- factor(PSE_diff$movdir,
                            levels = c("left", "right"),
                            labels = c("congruent", "incongruent"))

median_split <- ggplot(PSE_diff, aes(x = adaptation, y = PSE_diff, fill = adaptcon)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  facet_grid(movdir ~ adaptcon) +
  theme_minimal() +
  labs(y = "ΔPSE (median groups)", x = "Adaptation") +
  scale_fill_brewer(palette = "Set2") +
  theme(strip.text = element_text(size = 12, face = "bold")) + 
  guides(fill="none")

print(median_split)

# save_plot(median_split, "MedianSplitPlot.png", path_figures)
