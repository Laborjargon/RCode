# Imp Difference Plot 

diffs <- observer_means %>%
  pivot_wider(
    id_cols = c(person, condition),
    names_from = session,
    values_from = mean_coolness,
    names_prefix = "session"
  ) %>%
  mutate(diff = session2 - session1)

diff_violin <- ggplot(diffs, aes(x = condition, y = diff)) +
  geom_violin(fill = "lightblue", alpha = 0.4) +
  geom_jitter(width = 0.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(title = "Session Differences", y = "Session 2 − Session 1", x = "Condition") +
  theme_minimal()

print(diff_violin)

# save_plot()
