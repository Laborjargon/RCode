# Imp2 
# Compute average coolness for each person in syncP only
split_who <- observer_means %>%
  filter(condition == "syncP") %>%
  group_by(person) %>%
  summarise(avg_syncP = mean(mean_coolness), .groups = "drop")

# Create the split labels (top 50% → "high", bottom 50% → "low")
n_split <- floor(nrow(split_who) / 2)

split_who <- split_who %>%
  arrange(desc(avg_syncP)) %>%
  mutate(median_group = ifelse(row_number() <= n_split, "high", "low"))

# Add median group info to all_data and observer_means
all_data_split <- all_data %>%
  left_join(split_who %>% select(person, median_group), by = "person")

observer_means_split <- observer_means %>%
  left_join(split_who %>% select(person, median_group), by = "person")

violin_plot_split <- ggplot(all_data_split, aes(x = condition, y = coolness)) +
  geom_violin(aes(fill = condition), trim = FALSE, alpha = 0.4, show.legend = FALSE) +
  geom_jitter(data = observer_means_split, aes(y = mean_coolness),
              width = 0.05, alpha = 0.3, size = 2, color = "black") +
  stat_summary(fun.data = mean_se, geom = "errorbar",
               color = "#0072B2", width = 0.01, size = 1.5) +
  stat_summary(fun = mean, geom = "point",
               color = "#0072B2", size = 3) +
  theme_bw(base_size = 14) +
  scale_fill_brewer(palette = "Pastel1") +
  facet_grid(median_group ~ movdir) +  # 2x2 layout
  labs(
    title = "Distribution of Causality Ratings by Median Split and Movement Direction",
    x = "Condition",
    y = "Mean Rating (0–100)"
  ) +
  scale_y_continuous(limits = c(0, 100), breaks = seq(0, 100, 25))

print(violin_plot_split)

# sanity check 
0 == mean(all_data$coolness[which(all_data$condition == "syncL")],) - mean(all_data_split$coolness[which(all_data_split$condition == "syncL")],)

# save_plot(violin_plot_split, "violin_plot_split.png", path_figures)
