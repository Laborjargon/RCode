# facet wrap adaptor plots 
# 3 x 2 adaptcon x movdir (pre post adaptation within)

# PSE Plot ----------------------------------------------------------------
PSE_table <- fit$thresholds %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor))

PSE_table$adaptation <- factor(PSE_table$adaptation, levels = c("pre", "post"))

PSE_table$movdir <- factor(PSE_table$movdir,
                           levels = c("right", "left"),
                           labels = c("congruent", "incongruent"))

PSE_means <- PSE_table %>%
  group_by(adaptcon, movdir, adaptation, prob) %>%
  summarise(x = mean(thre), .groups = 'drop')


PSE_means <- PSE_means %>%
  left_join(
    PSE_cm_long %>%
      select(movdir, adaptation, adaptcon, ci_low, ci_upp),
    by = c("movdir", "adaptation", "adaptcon")
  )

PSE_table$adaptcon <- factor(PSE_table$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
PSE_means$adaptcon <- factor(PSE_means$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))
PSE_means$adaptation <- factor(PSE_means$adaptation, levels = c("pre", "post"))


PSE_plot <- ggplot(PSE_table, aes(x = adaptation, y = thre, color = adaptation)) +
  geom_jitter(width = 0.2, height = 0, size = 2, alpha = 0.4) +
  geom_errorbar(data = PSE_means, aes(x = adaptation, y = x, ymin = ci_low, ymax = ci_upp, color = adaptation),width = 0, size = 1.7) +
  geom_point(data = PSE_means, aes(x = adaptation, y = x), size = 3,position = position_dodge(width = 0.5)) + 
  facet_grid(movdir ~ adaptcon) +
  scale_color_manual(values = my_colors) +
  theme_minimal() +
  labs(
    y = "PSE"
  ) +
  theme(
    strip.text = element_text(size = 12),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  ) + 
  scale_x_discrete(expand = expansion(mult = c(2, 2)))

print(PSE_plot)

# save_plot(PSE_plot, "PSE_plot.png", path_figures)