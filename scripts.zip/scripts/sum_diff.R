# diff bar plot 
# Step 6: Compute total adaptation effect per condition and movement direction
total_adaptation <- d_diff %>%
  group_by(adaptcon, movdir) %>%
  summarise(
    sum_diff = sum(diff, na.rm = TRUE),  # sum across all discs and participants
    mean_diff = mean(diff, na.rm = TRUE), # optional: average effect
    se_diff = sd(diff, na.rm = TRUE) / sqrt(n()),
    .groups = "drop"
  ) %>%
  label_data()  # add readable labels if desired

# Show result
print(total_adaptation)

# Step 7: Bar plot of total adaptation effect
adaptation_barplot <- ggplot(total_adaptation, aes(x = condition, y = mean_diff, fill = movdir_label)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.7), width = 0.6) +
  labs(
    x = "Adaptation Condition",
    y = "Total Adaptation Effect (Before − After)",
    fill = "Movement Direction"
  ) +
  geom_errorbar(
    aes(ymin = mean_diff - se_diff, ymax = mean_diff + se_diff),
    width = 0.2,
    position = position_dodge(width = 0.7)
  ) +
  ylab("Cumulative Sum") + 
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "right",
    axis.text.x = element_text(size = 12),
    axis.title = element_text(size = 13),
    panel.grid.minor = element_blank()
  ) +
  scale_fill_manual(values = c("Rightward" = "#1f78b4", "Leftward" = "#e31a1c"))

print(adaptation_barplot)

# save_plot()
