# prepare data
dsmall <- subset(combined_data, select = c(3,5,6,8,26,29,30))
dsmall <- subset(dsmall, participant!=4)
dsmall <- subset(dsmall, session!=1)

colnames(dsmall)[colnames(dsmall) == "V3"] ="adaptation" # 0: pre, 1: post
colnames(dsmall)[colnames(dsmall) == "V5"] ="movdir"
colnames(dsmall)[colnames(dsmall) == "V6"] ="discs"
colnames(dsmall)[colnames(dsmall) == "V8"] ="adaptcon"
colnames(dsmall)[colnames(dsmall) == "V26"] ="answers"

dsmall$movdir <- as.numeric(dsmall$movdir)
dsmall$movdir[dsmall$movdir>1] = 1 # 0 = right; 1 = left

dsmall$adaptation <- as.factor(dsmall$adaptation)
dsmall$movdir <- as.factor(dsmall$movdir)
dsmall$adaptcon <- as.factor(dsmall$adaptcon)
dsmall$participant <- as.factor(dsmall$participant)
dsmall$session <- as.factor(dsmall$session)

