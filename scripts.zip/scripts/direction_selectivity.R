# Direction specificity analysis for multiple conditions
# Step 1: Process all conditions (SyncL, SyncP, ASyncP)

# Step 2: Compute difference between movdir for all conditions
d_dirsel_all <- d_diff %>%
  group_by(participant, adaptcon, discs) %>%   # x = discs
  summarise(
    dir_selectivity = mean(diff[movdir == "incongruent"]) -
      mean(diff[movdir == "congruent"]),
    .groups = "drop"
  )

# Step 3: Average across participants + SEM for each condition
d_avg_dirsel_all <- d_dirsel_all %>%
  group_by(adaptcon, discs) %>%
  summarise(
    mean_diff = mean(dir_selectivity),
    .groups = "drop"
  ) %>%
  rename(x = discs)

# Step 4: Join with confidence intervals from ci_diffmovdir_df
d_avg_dirsel_final <- d_avg_dirsel_all %>%
  left_join(
    ci_diffmovdir_df %>% select(adaptcon, x, ci_low, ci_upp),
    by = c("adaptcon", "x")
  )

# Step 5: Create polygon data for each condition
poly_data_dirsel_all <- d_avg_dirsel_final %>%
  group_by(adaptcon) %>%
  arrange(x) %>%
  do({
    df <- .
    data.frame(
      adaptcon = df$adaptcon[1],
      x = c(df$x, rev(df$x)),                    # forward then back
      y = c(df$mean_diff, rep(0, nrow(df)))      # curve then baseline
    )
  })

# Step 6: Define colors for each condition
condition_colors <- c("SyncL" = "#1f78b4", "SyncP" = "#33a02c", "ASyncP" = "#e31a1c")

# Step 7: Create the plot with facets
direc_select_multi <- ggplot(d_avg_dirsel_final, aes(x = x, y = mean_diff)) +
  geom_polygon(data = poly_data_dirsel_all, aes(x = x, y = y, fill = adaptcon), alpha = 0.2) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_upp, color = adaptcon), 
                alpha = 0.8, width = 0.1) +
  geom_line(aes(color = adaptcon), size = 1) +
  geom_point(aes(color = adaptcon), size = 3) +
  scale_color_manual(values = condition_colors) +
  scale_fill_manual(values = condition_colors) +
  labs(
    x = "Disc Overlap",
    y = "Direction Selectivity"
  ) +
  facet_wrap(~ adaptcon, ncol = 3) +
  theme_minimal(base_size = 13) +
  theme(
    panel.grid.minor = element_blank(),
    legend.position = "none",  # Remove legend since facet labels show conditions
    strip.text = element_text(face = "bold")
  )

print(direc_select_multi)


# save_plot(direc_select_multi, "direction_selectivity.png", path_figures)
