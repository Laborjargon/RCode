# fit data

# TODO add adaptation & mov dir & adaptcon columns back to PSE_table
# get ypred 
# add guess and lapse parameters -> just set to TRUE and init more parameters 
# facet wrap to make 3 x 2 adaptor pmf plots with adaptcon x mov dir and adaptation as within



xvals = seq(0,1,length.out=100)


dsmall <- dsmall %>%
  mutate(conditionlong = case_when(
    
    movdir == 1 & adaptation == 0 & adaptcon == 2   ~ "left_pre_SyncP",
    movdir == 1 & adaptation == 1 & adaptcon == 2   ~ "left_post_SyncP",
    
    movdir == 0 & adaptation == 0 & adaptcon == 2   ~ "right_pre_SyncP",
    movdir == 0 & adaptation == 1 & adaptcon == 2   ~ "right_post_SyncP",
    
    movdir == 1 & adaptation == 0 & adaptcon == 1   ~ "left_pre_SyncL",
    movdir == 1 & adaptation == 1 & adaptcon == 1   ~ "left_post_SyncL",
    
    movdir == 0 & adaptation == 0 & adaptcon == 1   ~ "right_pre_SyncL",
    movdir == 0 & adaptation == 1 & adaptcon == 1   ~ "right_post_SyncL",
    
    movdir == 1 & adaptation == 0 & adaptcon == 3   ~ "left_pre_ASyncP",
    movdir == 1 & adaptation == 1 & adaptcon == 3   ~ "left_post_ASyncP",
    
    movdir == 0 & adaptation == 0 & adaptcon == 3   ~ "right_pre_ASyncP",
    movdir == 0 & adaptation == 1 & adaptcon == 3   ~ "right_post_ASyncP",
    
    TRUE ~ NA_character_  # to catch unclassified cases
  )) %>%
  mutate(conditionlong = factor(conditionlong))

# unique(dsmall$conditionlong)
# table(dsmall$conditionlong)
fit <- quickpsy(dsmall,discs,answers,guess=TRUE,lapses=TRUE,prob=0.5,grouping = .("conditionlong","participant"), fun=logistic_fun2,parini=list(c(1,15),c(-40,-1),c(0,0.3),c(0,0.75)), bootstrap = "none")

PSE_table <- fit$thresholds %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor))


# stolen from sven --------------------------------------------------------

df_par <- as.data.frame(fit$par)
df_pse <- as.data.frame(fit$thresholds) # identical to PSE_table
df_pse$lower <- NaN
df_pse$upper <- NaN


# ANALYSIS OF PF
# -visualization
uniquelevels <- levels(df_par$conditionlong)
outpred <- c()

for(i in uniquelevels){
param <- df_par %>%
  filter(conditionlong==i) %>%
  group_by(parn) %>%
  summarise(mean=mean(par))
  xval <- seq(0,1,length.out=100)
  ypred <- logistic_fun2(xval,param$mean[1:2])
  condrep <- rep(i,times=length(xval))
  temppred <- data.frame(xval,ypred,condrep)
  outpred <- rbind(outpred,temppred)
}

interim <- ggplot(outpred,aes(x=xval,y=ypred,color=condrep))+geom_line()+theme_minimal()+ylab("Prop. causal reports")+xlab("Disc overlap")
m2dat <- dsmall %>%
  group_by(.,conditionlong,discs) %>%
  summarize(.,answers=mean(answers))
colnames(m2dat) <- c("condrep","xval","ypred")
interim <- interim + geom_point(aes(x=xval,y=ypred,color=condrep),data=m2dat) + theme(legend.title = element_blank())

colnames(outpred) <- c("discs","answers","conditionlong")
