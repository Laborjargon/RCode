# CM CI 

# participant means CM CI  ------------------------------------------------------------

participant_means <- dsmall %>%
  mutate(across(c(movdir, adaptation, adaptcon), as.factor)) %>%
  group_by(participant, conditionlong, discs) %>%
  summarise(y = mean(answers), .groups = "drop") %>%
  separate(conditionlong, into = c("movdir", "adaptation", "adaptcon"), sep = "_", remove = FALSE) %>%
  rename(x = discs)

wide_df <- participant_means %>%
  mutate(cond_id = paste(movdir, adaptation, adaptcon, x, sep = "_")) %>%
  select(participant, cond_id, y) %>%
  pivot_wider(names_from = cond_id, values_from = y)

ci_data <- wide_df %>% select(-participant)

ci_results <- ci.mean.w(ci_data, conf.level = 2*(pnorm(1.00,0,1)-0.5)) # this is where the magic happens; adjust conf.level

# Access lower and upper bounds
ci_bounds <- ci_results[["result"]][, c("low", "upp")]

# Add means back in
means <- ci_results[["result"]][, "m"]
cond_names <- colnames(ci_data)

ci_df <- data.frame(
  condition = cond_names,
  mean = means,
  ci_low = ci_bounds$low,
  ci_upp = ci_bounds$upp
)

cm_long <- ci_df %>%
  separate(condition, into = c("movdir", "adaptation", "adaptcon", "x"), sep = "_") %>%
  mutate(x = as.numeric(x))


# PSE CM CI  --------------------------------------------------------------

# Wide format: one row per participant, one column per condition
PSE_long <- PSE_table %>%
  ungroup() %>%
  select(-conditionlong)


PSE_wide <- PSE_long %>%
  mutate(cond_id = paste(movdir, adaptation, adaptcon, sep = "_")) %>%
  select(participant, cond_id, thre) %>%
  pivot_wider(names_from = cond_id, values_from = thre)

PSE_ci_data <- PSE_wide %>% select(-participant)

PSE_ci_results <- ci.mean.w(PSE_ci_data, conf.level = 0.95) # this is where the magic happens; adjust conf.level

# Access lower and upper bounds
PSE_ci_bounds <- PSE_ci_results[["result"]][, c("low", "upp")]

# Add means back in
means <- PSE_ci_results[["result"]][, "m"]
cond_names <- colnames(PSE_ci_data)

PSE_ci_df <- data.frame(
  condition = cond_names,
  thre = means,
  ci_low = PSE_ci_bounds$low,
  ci_upp = PSE_ci_bounds$upp
)

PSE_cm_long <- PSE_ci_df %>%
  separate(condition, into = c("movdir", "adaptation", "adaptcon"), sep = "_")


# difference means participants CM CI  -------------------------------------------------------

participant_diffs <- participant_means %>%
  select(participant, x, movdir, adaptation, adaptcon, y) %>%
  pivot_wider(names_from = adaptation, values_from = y) %>%
  mutate(adaptation_effect = post - pre)

wide_diff_df <- participant_diffs %>%
  mutate(cond_id = paste(movdir, adaptcon, x, sep = "_")) %>%
  select(participant, cond_id, adaptation_effect) %>%
  pivot_wider(names_from = cond_id, values_from = adaptation_effect)

ci_data_diff <- wide_diff_df %>% select(-participant)

ci_results_diff <- ci.mean.w(ci_data_diff, conf.level = 2*(pnorm(1.00, 0, 1) - 0.5))

ci_bounds_diff <- ci_results_diff[["result"]][, c("low", "upp")]
means_diff <- ci_results_diff[["result"]][, "m"]
cond_names_diff <- colnames(ci_data_diff)

ci_diff_df <- data.frame(
  condition = cond_names_diff,
  mean_diff = means_diff,
  ci_low = ci_bounds_diff$low,
  ci_upp = ci_bounds_diff$upp
) %>%
  separate(condition, into = c("movdir", "adaptcon", "x"), sep = "_") %>%
  mutate(x = as.numeric(x))

ci_diff_df$adaptcon <- factor(ci_diff_df$adaptcon, levels = c("SyncL", "SyncP", "ASyncP"))

ci_diff_df <- ci_diff_df %>%
  mutate(movdir = ifelse(movdir == "right", "congruent", "incongruent"))


# summed ΔPSE CMCI -------------------------------------------------------

summary_diffs <- participant_diffs %>%
  group_by(participant, movdir, adaptcon) %>%
  summarise(mean_adaptation_effect = mean(adaptation_effect, na.rm = TRUE), .groups = 'drop')

wide_summary_diffs <- summary_diffs %>%
  mutate(
    # Use the final labels for the columns
    movdir_label = ifelse(movdir == "right", "congruent", "incongruent"),
    condition_id = paste(movdir_label, adaptcon, sep = "_")
  ) %>%
  select(participant, condition_id, mean_adaptation_effect) %>%
  pivot_wider(names_from = condition_id, values_from = mean_adaptation_effect)

ci_data_input <- wide_summary_diffs %>% 
  select(-participant)

ci_results_summary <- ci.mean.w(ci_data_input, conf.level = 0.95)

ci_summary_df <- data.frame(
  condition = colnames(ci_data_input),
  mean_diff = ci_results_summary[["result"]][, "m"],
  ci_low = ci_results_summary[["result"]][, "low"],
  ci_upp = ci_results_summary[["result"]][, "upp"]
) %>%
  separate(condition, into = c("movdir", "adaptcon"), sep = "_", extra = "merge")


# direction selectivity CM CI  --------------------------------------------

diff_of_diffs <- participant_diffs %>%
  select(participant, movdir, adaptcon, x, adaptation_effect) %>%
  pivot_wider(names_from = movdir, values_from = adaptation_effect) %>%
  mutate(diff_movdir = left - right) # left = incongruent 

# Step 3: Prepare for CI computation
wide_diffmovdir_df <- diff_of_diffs %>%
  mutate(cond_id = paste(adaptcon, x, sep = "_")) %>%
  select(participant, cond_id, diff_movdir) %>%
  pivot_wider(names_from = cond_id, values_from = diff_movdir)

ci_data_diffmovdir <- wide_diffmovdir_df %>% select(-participant)

# Step 4: Compute CIs with misty::ci.mean.w()
ci_results_diffmovdir <- ci.mean.w(
  ci_data_diffmovdir,
  conf.level = 2 * (pnorm(1.00, 0, 1) - 0.5) # ~68% CI
)

# Step 5: Extract and reshape results
ci_bounds_diffmovdir <- ci_results_diffmovdir[["result"]][, c("low", "upp")]
means_diffmovdir <- ci_results_diffmovdir[["result"]][, "m"]
cond_names_diffmovdir <- colnames(ci_data_diffmovdir)

ci_diffmovdir_df <- data.frame(
  condition = cond_names_diffmovdir,
  mean_diff = means_diffmovdir,
  ci_low = ci_bounds_diffmovdir$low,
  ci_upp = ci_bounds_diffmovdir$upp
) %>%
  separate(condition, into = c("adaptcon", "x"), sep = "_") %>%
  mutate(x = as.numeric(x)) %>%
  mutate(adaptcon = factor(adaptcon, levels = c("SyncL", "SyncP", "ASyncP")))

