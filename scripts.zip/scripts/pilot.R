### Coca3 first analysis script 
library(quickpsy)
library(ggplot2)
library(tidyr)
library(reshape)


data <- read.delim("C:/Users/somme/Desktop/Masterarbeit/data/Coc3031.dat", header=FALSE)

dat_reduced <- subset(data, select = c(3,6,26))

colnames(dat_reduced)[colnames(dat_reduced) == "V3"] ="adaptation" # 0: pre, 1: post
colnames(dat_reduced)[colnames(dat_reduced) == "V6"] ="discs"
colnames(dat_reduced)[colnames(dat_reduced) == "V26"] ="answers"

dat_reduced$adaptation <- as.factor(dat_reduced$adaptation)

logistic_fun2 <- function (x, p) {(1 + exp(-(p[1]+p[2]*x)))^(-1)}
xvals = seq(0,1,length.out=100)

pmf_pre <- quickpsy(dat_reduced[dat_reduced$adaptation==0,],discs,answers,guess=0,lapses=F,prob=0.5, fun=logistic_fun2,parini=list(c(1,15),c(-40,-1)), bootstrap = "none")
pmf_post <- quickpsy(dat_reduced[dat_reduced$adaptation==1,],discs,answers,guess=0,lapses=F,prob=0.5, fun=logistic_fun2,parini=list(c(1,15),c(-40,-1)), bootstrap = "none")

pred_pre <- logistic_fun2(xvals,pmf_pre$par$par)
pred_post <- logistic_fun2(xvals,pmf_post$par$par)

pse_pre <- pmf_pre$thresholds$thre
pse_post <- pmf_post$thresholds$thre

plot_data <- data.frame(
  pre = pred_pre,
  post = pred_post,
  xvals = xvals
)

plot_long <- plot_data %>%
  gather(key = "Adaptation", value = "y_value", pre, post)

pse_data <- data.frame(pre = pse_pre, post = pse_post, xval = 0.5)
pse_long <- pse_data %>%
  gather(key="Adaptation", value = "pse", pre, post)

# adding the points 

pre_melt <- melt(dat_reduced[dat_reduced$adaptation == 0,],id=c("discs"),measure=c("answers"))
pre_cast <- cast(pre_melt,discs ~ variable,mean)
pre_cast$Adaptation = "pre"

post_melt <- melt(dat_reduced[dat_reduced$adaptation == 1,],id=c("discs"),measure=c("answers"))
post_cast <- cast(post_melt,discs ~ variable,mean)
post_cast$Adaptation = "post"

ben_plot <- ggplot(data = plot_long, aes(x = xvals, y = y_value, linetype = Adaptation, color = Adaptation)) +
  geom_line(size=1.5) + 
  labs(title = "Curves Pre and Post Adaptation",
       x = "Disc Overlap",
       y = "Proportion Causal Report",
       linetype = "Adaptation") +
  theme_classic() +
  xlim(0,1) + 
  ylim(0,1) +
  geom_point(data = pse_long, aes(x = pse, y = xval, color = Adaptation), size = 3, shape = 21, fill = "white") +
  geom_point(data = pre_cast, aes(x = discs, y = answers), size = 1.5, shape = 13) + 
  geom_point(data = post_cast, aes(x = discs, y = answers), size = 1.5, shape = 19)

print(ben_plot)
