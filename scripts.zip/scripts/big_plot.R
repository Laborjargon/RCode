# big plot 

simple_labeller <- labeller(
  adaptcon = label_value,
  movdir = label_value,
  participant = function(x) paste0("P", x)
)

# we need participant means, we did that in CM CI 
participant_means$movdir <- factor(participant_means$movdir,
                                levels = c("left", "right"),
                                labels = c("incongruent", "congruent"))

big_plot <- ggplot(predicted_curves, aes(x = x, y = y, color = adaptation, group = interaction(adaptation))) +
  geom_point(data = participant_means, aes(x = x, y = y, color = adaptation), shape = 20, size = 1, inherit.aes = FALSE)+
  geom_line(linewidth = 0.8) +
  facet_grid(
    rows = vars(adaptcon, movdir),
    cols = vars(participant),
    labeller = simple_labeller
  ) +
  scale_color_manual(
    values = c("pre" = "black", "post" = "red")
  ) +
  labs(
    title = "Psychometric Curves by Participant",
    x = "Disc Overlap [diam.]",
    y = "Causal Report"
  ) +
  theme_bw(base_size = 11) +
  theme(
    panel.grid = element_blank(),
    strip.text.x = element_text(size = 9),
    strip.text.y.left = element_text(size = 9, angle = 0, hjust = 0),
    strip.placement = "outside",
    strip.background = element_rect(fill = "grey90", color = NA),
    legend.position = "bottom"
  )

print(big_plot)

# save_plot(big_plot, "big_plot.png", path_figures)
