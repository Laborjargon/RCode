# different data from different folder 
imp_data <- paste(path_wd,"/data/imp",sep="")

# Get a list of all .dat files in the directory
file_list <- list.files(path = imp_data, pattern = "\\.dat$", full.names = TRUE)

# Create a function to read and process each file
read_and_process_file <- function(filepath) {
  # Read the data. We assume it's a space-separated file without a header.
  data <- read.table(filepath, header = FALSE, sep = "")
  
  # Create a data frame with the relevant columns
  processed_data <- data.frame(
    coolness = data$V26,
    contextcon = data$V12,
    evetype = data$V6,
    movdir = data$V5,
    # Extract observer ID from the filename (adjust if your filenames are different)
    id = sub("\\.dat$", "", basename(filepath))
  )
  
  return(processed_data)
}

# Apply the function to all files and combine them into a single data frame
all_data <- do.call(rbind, lapply(file_list, read_and_process_file))

all_data$movdir[all_data$movdir>1] = 1 # 0 = right; 1 = left 
all_data <- all_data %>%
  mutate(movdir = ifelse(movdir == 0, "congruent", "incongruent"))

# Correct condition mapping
all_data <- all_data %>%
  mutate(condition = case_when(
    evetype == 0 & contextcon == 1 ~ "Launch",
    evetype == 1 & contextcon == 1 ~ "Pass",
    evetype == 0 & contextcon == 2 ~ "syncL",
    evetype == 1 & contextcon == 2 ~ "syncP",
    evetype == 1 & contextcon == 3 ~ "asyncP",
    TRUE ~ "Unknown"
  )) %>%
  # Filter out any 'Unknown' rows if they exist
  filter(condition != "Unknown")

# Set a logical order for the conditions on the plot
# This is much better than the default alphabetical order
condition_order <- c("Launch", "Pass", "syncL", "syncP", "asyncP")
all_data$condition <- factor(all_data$condition, levels = condition_order)
all_data <- subset(all_data, id!="Imp3041")

# add session & person

all_data$session <- substr(all_data$id,
                           nchar(all_data$id),
                           nchar(all_data$id))

all_data$person <- substr(all_data$id,
                          nchar(all_data$id) - 2,
                          nchar(all_data$id) - 1)



# Calculate observer means & add session and person 
observer_means <- all_data %>%
  group_by(condition, id) %>%
  summarise(mean_coolness = mean(coolness, na.rm = TRUE), .groups = 'drop') %>%
  mutate(
    person = substr(id, nchar(id) - 2, nchar(id) - 1),
    session = substr(id, nchar(id), nchar(id))
  )


# Calculate condition means AND standard error for the error bars
condition_summary <- observer_means %>%
  group_by(condition) %>%
  summarise(
    grand_mean = mean(mean_coolness, na.rm = TRUE),
    sem = sd(mean_coolness, na.rm = TRUE) / sqrt(n()),
    .groups = 'drop'
  )


# who is where in the median split ----------------------------------------

split_who <- observer_means %>%
  group_by(condition, person) %>%
  summarise(avg = mean(mean_coolness)) %>%
  filter(condition == "syncP")

# the high group includes P:
split_who %>%
  slice_max(order_by = avg, n = 6)

split_who %>%
  slice_min(order_by = avg, n = 6)


# Code for the violin plot
violin_plot <- ggplot(all_data, aes(x = condition, y = coolness)) +
  
  # Add violin plots to show the distribution of ALL ratings
  geom_violin(aes(fill = condition), trim = FALSE, alpha = 0.4, show.legend = FALSE) +
  
  # Overlay jittered points for the individual observer means
  geom_jitter(data = observer_means, aes(y = mean_coolness),
              width = 0.05, alpha = 0.3, size = 2, color = "black") +
  # stat_summary(fun.data = mean_se, geom = "errorbar",
  #              color = "#0072B2", width = 0.01, size = 1.5) + 
  stat_summary(fun = mean, geom = "point",
               color = "#0072B2", size = 3) + 
  
  # Use a professional color palette and a clean theme
  theme_bw(base_size = 14) +
  scale_fill_brewer(palette = "Pastel1") + # Colors for the violin fill
  # facet_wrap(~movdir) +
  # Improve labels and set y-axis limits
  labs(
    title = "Distribution of Causality Ratings",
    x = "Condition",
    y = "Mean Rating (0-100)"
  ) +
  scale_y_continuous(limits = c(0, 100), breaks = seq(0, 100, 25))

print(violin_plot)

# save_plot(violin_plot, "violin_plot_split.png", path_figures)
