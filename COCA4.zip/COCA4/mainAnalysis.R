#--------------------------------------------------------------------------
# Run main script for analysis COCA4
# Putting causality into context: 
# Causal capture escapes the visual adaptation of causality
# By Sommer, Rolfs and Ohl
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Note:
# - all events in this experiment were from left to right
# - Coding: 1 = no context-event; 2 = launch context; 4 = pass context
# - Coding: adapos  1.5 == condorder 1 (vertical position shift; lower visual field)
# - Coding: adapos -1.5 == condorder 2 (vertical position shift; upper visual field)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Clear workspace
# Note rm() is bad coding. Check out this tutorial how to improve here:
# https://github.com/jennybc/debugging#readme
rm(list=ls())
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Define pathes 
# Note you need to set the current directory to the location of this file
path_wd 	   <- "C:/Users/somme/Desktop/COCA4"
path_data 	 <- paste(path_wd,"/_datfiles/",sep="")
path_figures <- paste(path_wd,"/_Figures/",sep="")
path_script  <- paste(path_wd,"/_RScripts/",sep="")
path_knits   <- paste(path_wd, "/_Knits/",sep="")
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# load packages
source(paste(path_script,"loadPackages.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# load packages
source(paste(path_script,"loadFunctions.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# define colors
source(paste(path_script,"loadColors.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# define theme
source(paste(path_script,"loadTheme.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# load data, assign names for columns and define variable type
source(paste(path_script,"loadData.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# generate new variables
source(paste(path_script,"genVariables.R",sep=""))
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Visualize psychometric curves

# Use only data for adaptation at test event location
dsmall <- data[which(data$condorder==1),] # there is only one condorder 

source(paste(path_script,"runAnalysis1.R",sep=""))
fig_pf <- fig
rm(fig)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Compute difference of mean proportion reported launches

# Use only data for adaptation at test event location
dsmall <- data[which(data$condorder==1),]

source(paste(path_script,"runAnalysis2.R",sep=""))
fig_delta <- fig
rm(fig)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# determine size of causal capture

# Use only data for adaptation at test event location
dsmall <- data[which(data$condorder==1),]

source(paste(path_script,"runAnalysis3.R",sep=""))
fig_context <- fig
rm(fig)
#--------------------------------------------------------------------------
source(paste(path_script,"ana2_flipped.R",sep=""))
fig_delta_flipped <- fig
rm(fig)

# -------------------------------------------------------------------------
source(paste(path_script,"ana3_flipped.R",sep=""))
fig_context_flipped <- fig
rm(fig)
#--------------------------------------------------------------------------
# Save Figure 
# all <- fig_pf +
#   fig_delta +
#   fig_delta_flipped +
#   fig_context +
#   fig_context_flipped +
#   plot_layout(byrow=FALSE, nrow = 2,heights=c(2,1,1,1,1), widths=c(1,1,1,1,1))
# 
# pdf(paste(path_figures,"Figure_COCA4_new.pdf",sep=""), width = (17.7*(1/1))/2.54, height = (17.7*(1/4))/2.54,useDingbats=FALSE)
# print(all)
# dev.off()
# new layout --------------------------------------------------------------


design <- 
"AABBCC
AADDEE"


all <- fig_pf +
  fig_delta +
  fig_delta_flipped +
  fig_context_flipped +
  fig_context +
  plot_layout(design = design)

pdf(paste(path_figures, "Figure_COCA4_new.pdf", sep=""), 
    width = (17.7 / 2.54), 
    height = (17.7 * (4/7)) / 2.54, 
    useDingbats = FALSE)
print(all)
dev.off()


ggsave(
  filename = paste(path_figures, "Figure_COCA4_new.svg", sep=""),
  plot = all,
  width = 17.7 / 2.54,
  height = (17.7 * (4/7)) / 2.54,
  units = "in"
)