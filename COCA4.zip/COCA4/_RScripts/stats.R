# COCA stats 

stats_obj <- c1 %>%
  group_by(ada, context, vp) %>%
  summarise(answer = mean(answer), .groups = 'drop')

t.test(stats_obj$answer[which(stats_obj$context=="2" & stats_obj$ada==0)],
       stats_obj$answer[which(stats_obj$context=="3" & stats_obj$ada==0)],
        paired=TRUE)

t.test(stats_obj$answer[which(stats_obj$context=="2" & stats_obj$ada==1)])

t.test(c3$answer[which(c3$context=="5")])

# should be the same

t.test(ada_df_old$answer[which(ada_df_old$context=="1")])

t.test(c3$answer[which(c3$context=="5" & c3$adafac==0)],)

t.test(ada_df_old$answer[which(ada_df_old$context=="1")],
       ada_df_old$answer[which(ada_df_old$context=="2")],
       paired=TRUE)

aov.m 		       <- aov(answer ~ contextfac + Error(vpfac/(contextfac)),data=c3)
summary(aov.m)

aov.m 		       <- aov(answer ~ adafac*contextfac + Error(vpfac/(adafac*contextfac)),data=c3)
summary(aov.m)



c3_new <- c3 %>%
  group_by(vp, context) %>%
  summarise(
    ada_diff = mean(answer[ada == 1]) - mean(answer[ada == 0]),
    .groups = "drop"
  )

t.test(c3_new$ada_diff[which(c3_new$context=="3")],)

t.test(c3_new$ada_diff[which(c3_new$context=="2")],
       c3_new$ada_diff[which(c3_new$context=="3")],
       paired=TRUE)

t.test(c3$answer[which(c3$context=="4" & c3$adafac==1)],
       c3$answer[which(c3$context=="5" & c3$adafac==1)],
       paired=TRUE)

c3_new$vp <- as.factor(c3_new$vp)
c3_new$context <- as.factor(c3_new$context)

aov.m 		       <- aov(ada_diff ~ context + Error(vp/(context)),data=c3_new) # add 2x2 instead of context
summary(aov.m)

c3 <- c3 %>%
  mutate(movdir = case_when(
    context == 2 ~ "grouped",
    context == 3 ~ "ungrouped",
    context == 4 ~ "grouped",
    context == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(movdir = as.factor(movdir))

c3 <- c3 %>%
  mutate(type = case_when(
    context == 2 ~ "launch",
    context == 3 ~ "launch",
    context == 4 ~ "pass",
    context == 5 ~ "pass",
    .default = NA
  )) %>%
  mutate(type = as.factor(type))

new_anova <- aov(answer ~ adafac * type * movdir + Error(vpfac / (adafac * type * movdir)), data = c3)

summary(new_anova)

ezANOVA(
  data = c3,
  dv = answer,
  wid = vpfac,
  within = .(adafac, type, movdir),
  detailed = TRUE
)
  

c1_new <- c1[c1$eve == 0.5,]
c1_new <- c1_new %>%
  group_by(vp, context) %>%
  summarise(
    answer = mean(answer[ada == 1]) - mean(answer[ada == 0]),
    .groups = "drop"
  )

t.test(c1_new$answer[which(c1_new$context=="1")],)
t.test(c1_new$answer[which(c1_new$context=="2")],)
t.test(c1_new$answer[which(c1_new$context=="3")],)
t.test(c1_new$answer[which(c1_new$context=="4")],)
t.test(c1_new$answer[which(c1_new$context=="5")],)

mean(c1_new$answer[c1_new$context == 5])
