#--------------------------------------------------------------------------
# load colors (see also rgb and col2rgb)
deforange <- rgb(241,148,46,max=255)
defgreen  <- rgb(100,255,100,max=255)
defblue   <- rgb(50,98,138,max=255)
defgrey   <- rgb(150,150,150,max=255)

# transparent colors for polygon
defblue1  <- rgb(172,218,242,alpha=100,maxColorValue=255)
deforange1<- rgb(255,200,100,alpha=189,maxColorValue=255)
defbrown1 <- rgb(246,208,153,alpha=100,maxColorValue=255)
defgreen1 <- rgb(145,208,84,alpha=189,maxColorValue=255)

#mycol1 <- c("#bc5090","#003f5c","#58508d","#ff6361","#ffa600") #order 2 3 1 4 5
mycol1 <- c("#ff6361","#003f5c","#003f5d","#21918c","#21918d") #order red, blue, green

# new colours: c("#ff6361","#003f5c","#2E8EBF","#21918c","#EAB23F")
#--------------------------------------------------------------------------