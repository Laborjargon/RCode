# analysis 2 flipped
#--------------------------------------------------------------------------
# ... confidence interval for repeated measures design - based on Cousineau Morey
m1 <- melt(dsmall,id=c("ada","context","eve","vp"),measure=c("answer"))
c1 <- cast(m1,ada+context+eve+vp ~ variable,mean)

c0diff <- c1[85:420,(1:4)]
c0diff$answer <- c1$answer[which(c1$context>1 & c1$ada==0)]-rep(c1$answer[which(c1$context==1 & c1$ada==0)])

c1diff <- c1[(420+85):840,(1:4)]
c1diff$answer <- c1$answer[which(c1$context>1& c1$ada==1)]-rep(c1$answer[which(c1$context==1 & c1$ada==1)])

c1diff <- as.data.frame(rbind(c0diff,c1diff))
c1diff <- c1diff %>%
  group_by(context, eve, vp) %>%
  summarise(answer = answer[ada == 1] - answer[ada == 0])

m2 <- melt(c1diff,id=c("context","eve"),measure=c("answer"))
c2 <- cast(m2,context+eve ~ variable,mean)

# m2 <- melt(c1diff, id=c("ada","context","eve"), measure=c("answer"))
# c2 <- cast(m2, context+eve ~ ada, mean)
# 
# c2$diff <- c2$`1` - c2$`0`
# c2 <- c2 %>% 
#   mutate(answer = diff) %>%
#   select(-"0", -"1", -"diff")
# 
c2$contextfac <- as.factor(c2$context)

# -------------------------------------------------------------------------
c1diff$cond <-  as.factor(paste(as.integer(round(c1diff$eve*100)),as.integer(c1diff$context)))
c1diff_reduced <- c1diff[,c("answer","cond")]
c1diff_reduced <- unstack(c1diff_reduced)

ci_cm <- cm.ci(data.frame=c1diff_reduced,conf.level=2*(pnorm(1.00,0,1)-0.5),difference=TRUE)

c2 <- sort_by(c2,c2$eve)

c2$upper <- ci_cm[c(1:4,9:28,5:8),2]
c2$lower <- ci_cm[c(1:4,9:28,5:8),1]

c2 <- c2 %>%
  mutate(grouping = case_when(
    contextfac == 2 ~ "grouped",
    contextfac == 3 ~ "ungrouped",
    contextfac == 4 ~ "grouped",
    contextfac == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))
# -------------------------------------------------------------------------
df_tri <- c2 %>%
  group_by(contextfac) %>%
  group_modify(~ {
    x_pts <- .x$eve
    y_pts <- .x$answer
    data.frame(
      xpos = c(0, x_pts, rev(x_pts), 0),
      ypos = c(0, y_pts, rep(0, length(y_pts)), 0)
    )
  }) %>%
  ungroup()

df_tri <- df_tri %>%
  mutate(grouping = case_when(
    contextfac == 2 ~ "grouped",
    contextfac == 3 ~ "ungrouped",
    contextfac == 4 ~ "grouped",
    contextfac == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))

ytitle <- "Magnitude of capture [prop.]"

fig <- ggplot(c2,aes(x=eve,y=answer,colour=contextfac, linetype = grouping))
#fig <- fig + facet_wrap(.~contextfac,nrow=1)
fig <- fig + scale_colour_manual(values=mycol1[2:5])
fig <- fig + scale_fill_manual(values=mycol1[2:5])
fig <- fig + scale_x_continuous(limits=c(0,1),breaks=c(0,0.25,0.5,0.75,1))
fig <- fig + scale_y_continuous(limits=c(-0.5,0.5))#,expand = expand_scale(mult=0))
fig <- fig + geom_polygon(data=df_tri,
                          aes(x=xpos, y=ypos, fill=contextfac,
                              group=contextfac),
                          alpha=0.2, lwd=0)
fig <- fig + mytheme
fig <- fig + ylab(ytitle) + xlab("Disk overlap [proportion]")
fig <- fig + theme(plot.background=element_rect(fill = "transparent",colour = NA))
fig <- fig + scale_linetype_manual(values = c("ungrouped" = "dashed","grouped" = "solid"))
fig <- fig + geom_line(size=0.5)
fig <- fig + geom_linerange(data=c2,aes(ymax=upper,ymin=lower),size=0.5, linetype = "solid")
fig <- fig + geom_point(shape=16,size=2)
#--------------------------------------------------------------------------