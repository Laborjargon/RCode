#--------------------------------------------------------------------------
# load packages
# by Sven Ohl
#--------------------------------------------------------------------------

# ... for data preprocessing
#library(tidyverse)
library(ggplot2)
library(reshape)
#library(pracma)
#library(grid)
library(dplyr)
#library(devtools) # includes install_github("jonocarroll/ggshape")
#library(parallel)

# ... for basic statistical analysis
#library(circular)
#library(maxLik)
#library(minpack.lm)
#library(afex)       # Henrik Singmann
#library(lsmeans)    # for pairwise comparisons
library(ez)				# includes Greenhouse Geisser correction for ANOVA
#library(timereg)   # Includes Aalen's additive hazard model

# ... for permutation test/ bootstrapping/ resampling
# library(coin) for oneway_test(), pvalue()
# library(perm) for permTS()
# library(exactRankTests) for perm.test()

# ... for Bayesian analysis
#library(BayesFactor)
#library(brms)
#library(tidybayes)
#library(rstan)

# ... for data visualization
#library(bbplot) # bbc visualization package
#library(scales) #allows to avoid geom_bar from zero
library(patchwork) # Thomas Pederson package

#library(papaja)  #formating apa
#library(cowplot) #Wilkelab for visualization

# ... for colour palettes
#ibrary(viridis)
#library(wesanderson)

library(quickpsy)
#library(inflection)
#--------------------------------------------------------------------------