#--------------------------------------------------------------------------
# ... confidence interval for repeated measures design - based on Cousineau Morey
# COCA4
m1 <- melt(dsmall,id=c("ada","context","eve","vp"),measure=c("answer"))
c1 <- cast(m1,ada+context+eve+vp ~ variable,mean)

c0diff <- c1[85:420,(1:4)]
c0diff$answer <- c1$answer[which(c1$context>1 & c1$ada==0)]-rep(c1$answer[which(c1$context==1 & c1$ada==0)],times=2)

c1diff <- c1[(420+85):840,(1:4)]
c1diff$answer <- c1$answer[which(c1$context>1& c1$ada==1)]-rep(c1$answer[which(c1$context==1 & c1$ada==1)],times=2)

c1diff <- as.data.frame(rbind(c0diff,c1diff))
m2 <- melt(c1diff,id=c("ada","context","eve"),measure=c("answer"))
c2 <- cast(m2,ada+context+eve ~ variable,mean)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# compute the cumulative context effect
m3 <- melt(c1diff,id=c("ada","context","vp"),measure=c("answer"))
c3 <- cast(m3,ada+context+vp ~ variable,sum)

m4 <- melt(c3,id=c("ada","context"),measure=c("answer"))
c4 <- cast(m4,ada+context ~ variable,mean)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# compute CI
c3$cond <-  as.factor(paste(as.integer(c3$ada),as.integer(round(c3$context))))
c3_reduced <- c3[,c("answer","cond")]
c3_reduced <- unstack(c3_reduced)

ci_cm <- cm.ci(data.frame=c3_reduced,conf.level=2*(pnorm(1.00,0,1)-0.5),difference=TRUE)

c4$upper <- ci_cm[,2]
c4$lower <- ci_cm[,1]
#--------------------------------------------------------------------------


#--------------------------------------------------------------------------
c3$adafac <- as.factor(c3$ada)
c3$contextfac <- as.factor(c3$context)
c3$vpfac <- as.factor(c3$vp)

aov.m 		       <- aov(answer ~ adafac*contextfac + Error(vpfac/(adafac*contextfac)),data=c3)
summary(aov.m)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
c4$adafac <- as.factor(c4$ada)
c4$contextfac <- as.factor(c4$context)

# new layout --------------------------------------------------------------

#c4$ada_xshift <- c4$ada+c(-0.375,-0.125,0.125,0.375, 0.25,0.5,0.75,1)*2 
# 
# fig <- ggplot(c4,aes(x=ada_xshift,y=answer,fill=contextfac))
# fig <- fig + scale_colour_manual(values=mycol1[2:5])
# fig <- fig + scale_fill_manual(values=mycol1[2:5])
# fig <- fig + scale_x_continuous(limits=c(-1,3.25),breaks=c(0,2.25),labels=c("pre","post"))
# fig <- fig + scale_y_continuous(limits=c(-2,2))#,expand = expand_scale(mult=0))
# fig <- fig + mytheme
# fig <- fig + ylab("Cumulative capture [diam.]") + xlab("Adaptation")
# #fig <- fig + geom_point(shape=15,size=2.5)
# fig <- fig + geom_col(width=0.5)
# fig <- fig + geom_hline(yintercept=0)
# #fig <- fig + geom_jitter(data=c3,width=0.2)
# fig <- fig + geom_linerange(data=c4,aes(ymax=upper,ymin=lower),size=0.5)
# fig <- fig + theme(plot.background=element_rect(fill = "transparent",colour = NA))
# #print(fig)


# old layout --------------------------------------------------------------
# c4$ada_xshift <- c4$ada+c(-0.1,0.1,-0.1,0.1)*2
# fig <- ggplot(c4,aes(x=ada_xshift,y=answer,fill=contextfac))
# fig <- fig + geom_hline(yintercept=0)
# fig <- fig + scale_colour_manual(values=mycol1[2:5])
# fig <- fig + scale_fill_manual(values=mycol1[2:5])
# fig <- fig + scale_x_continuous(limits=c(-0.5,1.5),breaks=c(0,1),labels=c("pre","post"))
# fig <- fig + scale_y_continuous(limits=c(-2,2))#,expand = expand_scale(mult=0))
# fig <- fig + mytheme
# fig <- fig + ylab("Cumulative capture [prop.]") + xlab("Adaptation")
# #fig <- fig + geom_point(shape=15,size=2.5)
# fig <- fig + geom_col(width=0.4)
# #fig <- fig + geom_jitter(data=c3,width=0.2)
# fig <- fig + geom_linerange(data=c4,aes(ymax=upper,ymin=lower),size=0.5)
# fig <- fig + theme(plot.background=element_rect(fill = "transparent",colour = NA)) 
#--------------------------------------------------------------------------


c4$is_ungrouped <- c4$contextfac %in% c(3, 5)

# adaptation x-shift 
c4$ada_xshift <- c4$ada+c(-0.105,0.1,-0.105,0.1)*2

fig <- ggplot(c4, aes(x=ada_xshift, y=answer, fill=contextfac, color=contextfac, linetype = is_ungrouped, alpha=is_ungrouped))
fig <- fig + scale_colour_manual(values=mycol1[2:5])
fig <- fig + scale_fill_manual(values=mycol1[2:5])
fig <- fig + scale_alpha_manual(values=c("FALSE"=1, "TRUE"=0.7))
fig <- fig + scale_linetype_manual(values=c("FALSE"="solid", "TRUE"="dashed"))
fig <- fig + scale_x_continuous(limits=c(-0.5,1.5), breaks=c(0,1), labels=c("pre","post"))
fig <- fig + scale_y_continuous(limits=c(-2,2))
fig <- fig + mytheme
fig <- fig + ylab("Cumulative capture [prop.]") + xlab("Adaptation")
fig <- fig + geom_col(width=0.4)
fig <- fig + geom_col(data=c4[c4$is_ungrouped,], width=0.4, fill=NA, linewidth=0)
fig <- fig + geom_hline(yintercept=0)
fig <- fig + geom_linerange(data=c4, aes(ymax=upper, ymin=lower), size=0.5, linetype = "solid", color="black")
fig <- fig + theme(plot.background=element_rect(fill="transparent", colour=NA))

