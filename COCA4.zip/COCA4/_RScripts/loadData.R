#--------------------------------------------------------------------------
filetype <- 1
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# Load data			
if (filetype == 1){
datlist <- dir(path_data)

cnt      <- 0
data     <- c()
for(i in datlist){
  print(i)
  d1 <- read.table(paste(path_data,i,sep=""))
  colnames(d1) <- c("block","trial","ada","adaPos",
                      "eveDir","eve","eveEcc",
                    "condorder","context","adaLR",
                    "IDK","adaUPDOWN",
                    "eveDur","iniDist","testPosx","testPosy",
                      "tFixPosx","tFixPosy","tFix","tStart",
                      "tEvent","tEndMo","tClear",
                      "tResp","keyRT","answer",
                      "mMF")
  vpnum        <- as.numeric(substr(i,5,6))
  sessionnum   <- as.numeric(substr(i,7,7))
  d1$vp <- vpnum
  d1$session <- sessionnum
  
  d1$difftrial <- c(0,diff(d1$trial))
  idxtrain <- c()
  idxtrain <- which(d1$difftrial<0 & d1$block==1)
  if(length(idxtrain)>0){
    idxtrain <- seq(1,idxtrain-1)
    d1 <- d1[-idxtrain,]
  }
  
  if(sessionnum > 1){
  data  <- rbind(data,d1)
  }
}


}
#--------------------------------------------------------------------------