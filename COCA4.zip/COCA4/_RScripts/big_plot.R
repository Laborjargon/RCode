dsmall_avg <- dsmall %>%
  group_by(vpfac, session, eve) %>%
  summarise(mean_answer = mean(answer, na.rm = TRUE)) %>%
  ungroup()

big_plot <- ggplot(dsmall_avg, aes(x = eve, y = mean_answer, group = as.factor(session))) +
  geom_line(aes(linetype = as.factor(session)), color = "firebrick", size = 0.8) +
  geom_point(color = "firebrick", size = 2) +
  facet_wrap(~ vpfac, ncol = 4, labeller = label_both) +
  theme_bw() +
  theme(legend.position="none") +
  labs(
    title = "Average Answer by Participant",
    x = "Overlap",
    y = "Average Answer"
  ) +
  scale_y_continuous(breaks = c(0, 0.5, 1), limits = c(0, 1))

print(big_plot)