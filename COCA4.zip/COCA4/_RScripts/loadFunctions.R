#--------------------------------------------------------------------------
# load helper functions
se_up   <-  function(x){mean(x) + 1.96*sd(x)/sqrt(length(x))}
se_down <-  function(x){mean(x) - 1.96*sd(x)/sqrt(length(x))}

# load helper function for cousineau morey
cm.ci <- function(data.frame, conf.level = 0.95, difference = TRUE) {
  #cousineau-morey within-subject CIs
  k = ncol(data.frame)
  if (difference == TRUE) 
    diff.factor = 2^0.5/2
  else diff.factor = 1
  n <- nrow(data.frame)
  df.stack <- stack(data.frame)
  index <- rep(1:n, k)
  p.means <- tapply(df.stack$values, index, mean)
  norm.df <- data.frame - p.means + (sum(data.frame)/(n * k))
  t.mat <- matrix(, k, 1)
  mean.mat <- matrix(, k, 1)
  for (i in 1:k) t.mat[i, ] <- t.test(norm.df[i])$statistic[1]
  for (i in 1:k) mean.mat[i, ] <- mean(as.matrix(norm.df[i]))
  c.factor <- (k/(k - 1))^0.5
  moe.mat <- mean.mat/t.mat * qt(1 - (1 - conf.level)/2, n - 1) * c.factor * 
    diff.factor
  ci.mat <- matrix(, k, 2)
  dimnames(ci.mat) <- list(names(data.frame), c("lower", "upper"))
  for (i in 1:k) {
    ci.mat[i, 1] <- mean.mat[i] - moe.mat[i]
    ci.mat[i, 2] <- mean.mat[i] + moe.mat[i]
  }
  ci.mat
}

wrap <- function(x){
  bound <- 0.5
  #out <- mod(x + bound, bound*2) - bound
  out <- (x + bound) %%(bound*2) - bound
  out
}

findBorders <- function(x,xvals){
  x <- x - 0.5
  xvals_end <- xvals[min(which(x<0))]
  xvals_start   <- xvals[max(which(x>0))]
  out <- c(xvals_start,xvals_end)
  out
}


findPSEindex <- function(x){
  x <- x - 0.5
  PSEindex <- which(abs(x)==min(abs(x)))
  PSEval <- x[PSEindex]+0.5
  out <- c(PSEindex,PSEval)
  out
} 

pd <- function(x,cond1,cond2,dir){
  pse_diff <- x[cond1,]-x[cond2,]
  pd <- ifelse(dir == 1,length(which(pse_diff>0))/length(pse_diff),length(which(pse_diff<0))/length(pse_diff))
  pd
} 
#--------------------------------------------------------------------------