#--------------------------------------------------------------------------
# ... confidence interval for repeated measures design - based on Coussineau Morey
m1 <- melt(dsmall,id=c("eve","ada","context","vp"),measure=c("answer"))
c1 <- cast(m1,ada+eve+context+vp ~ variable,mean)

c1diff <- c1[1:420,(2:5)]
c1diff$answer <- c1$answer[which(c1$ada==1)]-c1$answer[which(c1$ada==0)]

c1diff <- as.data.frame(c1diff)
m2 <- melt(c1diff,id=c("eve","context"),measure=c("answer"))
c2 <- cast(m2,eve+context ~ variable,mean)


m3 <- melt(c1diff,id=c("context","vp"),measure=c("answer"))
c3 <- cast(m3,context+vp ~ variable,sum)

m4 <- melt(c3,id=c("context"),measure=c("answer"))
c4 <- cast(m4,context ~ variable,mean)
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
c3_reduced <- c3[,c("answer","context")]
c3_reduced <- unstack(c3_reduced)

ci_cm <- cm.ci(data.frame=c3_reduced,conf.level=2*(pnorm(1.96,0,1)-0.5),difference=TRUE)

c4$upper <- ci_cm[,2]
c4$lower <- ci_cm[,1]

# compute ANOVA based on c3
c3$vpfac <- as.factor(c3$vp)
c3$contextfac <- as.factor(c3$context)

ada_df_old <- c3

aov.m 		       <- aov(answer ~ contextfac + Error(vpfac/(contextfac)),data=c3)
summary(aov.m)

# post hoc t-tests
t.test(c3$answer[which(c3$context=="1")],
       c3$answer[which(c3$context=="2")],
       paired=TRUE)

t.test(c3$answer[which(c3$context=="1")],
       c3$answer[which(c3$context=="4")],
       paired=TRUE)

t.test(c3$answer[which(c3$context=="2")],
       c3$answer[which(c3$context=="4")],
       paired=TRUE)

t.test(
  c3$answer[which(c3$context=="1")],
)

t.test(
  c3$answer[which(c3$context=="2")],
)

t.test(
       c3$answer[which(c3$context=="4")],
       )
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
c1diff$cond <-  as.factor(paste(as.integer(round(c1diff$eve*100)),as.integer(c1diff$context)))
c1diff_reduced <- c1diff[,c("answer","cond")]
c1diff_reduced <- unstack(c1diff_reduced)

ci_cm <- cm.ci(data.frame=c1diff_reduced,conf.level=2*(pnorm(1.00,0,1)-0.5),difference=TRUE)

c2$upper <- ci_cm[c(1:5,11:35,6:10),2]
c2$lower <- ci_cm[c(1:5,11:35,6:10),1]
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# organize c2 for visualiztion
#ytitle <- expression(paste(Delta," adaptation [diameters]"))
ytitle <- "Magnitude of adaptation [prop.]"

c2$contextfac <- as.factor(c2$context)
levels(c2$contextfac) <-  c("without","launch_grouped","launch_ungrouped","pass_grouped","pass_ungrouped")

t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0.167)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0.333)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0.5)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0.667)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 0.833)])
t.test(c1diff$answer[which(c1diff$context=="1" & c1diff$eve == 1)])

t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0.167)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0.333)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0.5)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0.667)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 0.833)])
t.test(c1diff$answer[which(c1diff$context=="2" & c1diff$eve == 1)])

t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0.167)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0.333)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0.5)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0.667)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 0.833)])
t.test(c1diff$answer[which(c1diff$context=="3" & c1diff$eve == 1)])

t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0.167)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0.333)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0.5)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0.667)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 0.833)])
t.test(c1diff$answer[which(c1diff$context=="4" & c1diff$eve == 1)])

t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0.167)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0.333)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0.5)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0.667)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 0.833)])
t.test(c1diff$answer[which(c1diff$context=="5" & c1diff$eve == 1)])
#--------------------------------------------------------------------------
#--------------------------------------------------------------------------
# add grouping to c2 
c2 <- c2 %>%
  mutate(grouping = case_when(
    context == 1 ~ "grouped", # not technically correct 
    context == 2 ~ "grouped",
    context == 3 ~ "ungrouped",
    context == 4 ~ "grouped",
    context == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))

c2$contextfac <- as.factor(c2$context)
#--------------------------------------------------------------------------
# determine adaptation area
df_tri <- c2 %>%
  arrange(context, eve) %>%
  group_by(context) %>%
  group_modify(~ {
    rbind(
      data.frame(xpos = 0, ypos = 0, grouping = .x$grouping[1]),  # left anchor
      data.frame(xpos = .x$eve, ypos = .x$answer, grouping = .x$grouping),  # data points
      data.frame(xpos = 1, ypos = 0, grouping = .x$grouping[1])   # right anchor
    )
  }) %>%
  ungroup() %>%
  mutate(contextfac = as.factor(context))

df_tri <- df_tri %>%
  mutate(grouping = case_when(
    contextfac == 1 ~ "grouped", # not technically correct 
    contextfac == 2 ~ "grouped",
    contextfac == 3 ~ "ungrouped",
    contextfac == 4 ~ "grouped",
    contextfac == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))

#--------------------------------------------------------------------------
fig <- ggplot(c2,aes(x=eve,y=answer,colour=contextfac, fill= contextfac, linetype = grouping))
#fig <- fig + facet_wrap(.~contextfac,nrow=1)
fig <- fig + scale_colour_manual(values=mycol1)
fig <- fig + scale_fill_manual(values=mycol1)
fig <- fig + scale_x_continuous(limits=c(0,1),breaks=c(0,0.25,0.5,0.75,1))
fig <- fig + scale_y_continuous(limits=c(-0.5,0.5))#,expand = expand_scale(mult=0))
fig <- fig + geom_polygon(data = df_tri,
                          aes(x = xpos, y = ypos, fill = contextfac,
                              group = contextfac, linetype = grouping),
                          alpha = 0.2, lwd = 0)
fig <- fig + mytheme
fig <- fig + ylab(ytitle) + xlab("Disk overlap [proportion]")
fig <- fig + theme(plot.background=element_rect(fill = "transparent",colour = NA))
fig <- fig + scale_linetype_manual(values = c("ungrouped" = "dashed","grouped" = "solid"))
fig <- fig + geom_line(size=0.5)
fig <- fig + geom_linerange(data=c2,aes(ymax=upper,ymin=lower),size=0.5, linetype = "solid")
fig <- fig + geom_point(shape=16,size=2)
#--------------------------------------------------------------------------