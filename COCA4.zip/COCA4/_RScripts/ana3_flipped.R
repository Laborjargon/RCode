# analysis 3 flipped 

#--------------------------------------------------------------------------
# ... confidence interval for repeated measures design - based on Coussineau Morey
m1 <- melt(dsmall,id=c("eve","ada","context","vp"),measure=c("answer"))
c1 <- cast(m1,ada+eve+context+vp ~ variable,mean)

c1diff <- c1[1:420,(2:5)]
c1diff$answer <- c1$answer[which(c1$ada==1)]-c1$answer[which(c1$ada==0)]

c1diff <- as.data.frame(c1diff)
m2 <- melt(c1diff,id=c("eve","context"),measure=c("answer"))
c2 <- cast(m2,eve+context ~ variable,mean)


m3 <- melt(c1diff,id=c("context","vp"),measure=c("answer"))
c3 <- cast(m3,context+vp ~ variable,sum)

m4 <- melt(c3,id=c("context"),measure=c("answer"))
c4 <- cast(m4,context ~ variable,mean)
#--------------------------------------------------------------------------
c3$cond <-  as.factor(paste(as.integer(c3$ada),as.integer(round(c3$context))))
c3_reduced <- c3[,c("answer","cond")]
c3_reduced <- unstack(c3_reduced)

ci_cm <- cm.ci(data.frame=c3_reduced,conf.level=2*(pnorm(1.00,0,1)-0.5),difference=TRUE)

c4$upper <- ci_cm[,2]
c4$lower <- ci_cm[,1]
#--------------------------------------------------------------------------

c4$xshift <- c(0.82, 0.0, 0.41, 1.24, 1.65)
c4$contextfac <- as.factor(c4$context)

c4$is_ungrouped <- c4$contextfac %in% c(3, 5)

fig <- ggplot(c4, aes(x=xshift, y=answer, fill=contextfac, color=contextfac, linetype=is_ungrouped, alpha=is_ungrouped))
fig <- fig + scale_colour_manual(values=mycol1)
fig <- fig + scale_fill_manual(values=mycol1)
fig <- fig + scale_alpha_manual(values=c("FALSE"=1, "TRUE"=0.7))
fig <- fig + scale_linetype_manual(values=c("FALSE"="solid", "TRUE"="dashed"))
fig <- fig + scale_x_continuous(limits=c(-0.2,2))
fig <- fig + scale_y_continuous(limits=c(-2,2))
fig <- fig + mytheme
fig <- fig + ylab("Cumulative adaptation [prop.]") + xlab("Condition")
fig <- fig + geom_col(width=0.4)
fig <- fig + geom_col(data=c4[c4$is_ungrouped,], width=0.4, fill=NA, linewidth=0)
fig <- fig + geom_hline(yintercept=0)
fig <- fig + geom_linerange(data=c4, aes(ymax=upper, ymin=lower), size=0.5, linetype="solid", color="black")
fig <- fig + theme(plot.background=element_rect(fill="transparent", colour=NA))

