#--------------------------------------------------------------------------
# Generate new variables

# test condition
idx1 <- which(data$ada==0 & data$context==1)
idx2 <- which(data$ada==0 & data$context==2)
idx3 <- which(data$ada==0 & data$context==3)
idx4 <- which(data$ada==0 & data$context==4)
idx5 <- which(data$ada==0 & data$context==5)

idx6 <- which(data$ada==1 & data$context==1)
idx7 <- which(data$ada==1 & data$context==2)
idx8 <- which(data$ada==1 & data$context==3)
idx9 <- which(data$ada==1 & data$context==4)
idx10 <- which(data$ada==1 & data$context==5)

data$testcond=999
data$testcond[idx1] <- 1
data$testcond[idx2] <- 2
data$testcond[idx3] <- 3
data$testcond[idx4] <- 4
data$testcond[idx5] <- 5
data$testcond[idx6] <- 6
data$testcond[idx7] <- 7
data$testcond[idx8] <- 8
data$testcond[idx9] <- 9
data$testcond[idx10] <- 10

table(data$testcond)

# test condition as factor
data$testcondfac <- as.factor(data$testcond)
levels(data$testcondfac) <- c("pre_c1",
                              "pre_c2",
                              "pre_c3",
                              "pre_c4",
                              "pre_c5",
                            
                              "post_c1",
                              "post_c2",
                              "post_c3",
                              "post_c4",
                              "post_c5"
                              )


# 
data$adacomb <- data$adaLR * data$ada

# factor for subjects
data$vpfac <- as.factor(data$vp)
#--------------------------------------------------------------------------