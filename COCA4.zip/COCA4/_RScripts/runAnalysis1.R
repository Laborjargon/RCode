#--------------------------------------------------------------------------
# ... confidence interval for repeated measures design - based on Cousineau Morey
m1 <- melt(dsmall,id=c("eve","ada","context","vp"),measure=c("answer"))
c1 <- cast(m1,eve+ada+context+vp ~ variable,mean)

m2 <- melt(c1,id=c("eve","ada","context"),measure=c("answer"))
c2 <- cast(m2,eve+ada+context ~ variable,mean)
#--------------------------------------------------------------------------

#--------------------------------------------------
# compute mean pse value and confidence intervals
# ... to do

logistic_fun2 <- function (x, p) {(1 + exp(-(p[1]+p[2]*x)))^(-1)}
pmf_viz <- quickpsy(dsmall,eve,answer,guess=TRUE,lapses=TRUE,prob=0.5,grouping = .("ada","context"),fun=logistic_fun2,parini=list(c(1,15),c(-40,-1),c(0.0001,0.75),c(0.0001,0.75)), bootstrap = "none")
df_par <- as.data.frame(pmf_viz$par)

df_par$ada <- as.factor(df_par$ada)
df_par$context <- as.factor(df_par$context)
uniquelevels1 <- levels(df_par$ada)
uniquelevels2 <- levels(df_par$context)
outpred <- c()

for(i in uniquelevels1){
  print(i)
  for(j in uniquelevels2){
    print(j)
    param <- df_par %>%
      filter(ada==i & context==j) %>%
      group_by(parn) %>%
      summarise(mean=mean(par))
    xval <- seq(0,1,length.out=100)
    ypred <- param$mean[3]+(1-param$mean[3]-param$mean[4])*logistic_fun2(xval,param$mean[1:2])
    condrep1 <- rep(i,times=length(xval))
    condrep2 <- rep(j,times=length(xval))
    
    temppred <- data.frame(xval,ypred,condrep1,condrep2)
    outpred <- rbind(outpred,temppred)
    #cat("lapse:",param[3,2])
  }}

colnames(outpred) <- c("eve","answer","ada","context")

c2$adafac        <- as.factor(c2$ada)
levels(c2$adafac) <- c("before","after")
c2$contextfac <- as.factor(c2$context)
levels(c2$contextfac) <- c("without","launch_grouped","launch_ungrouped","pass_grouped","pass_ungrouped")

outpred$adafac        <- as.factor(outpred$ada)
levels(outpred$adafac) <- c("before","after")
outpred$contextfac <- as.factor(outpred$context)

levels(outpred$contextfac) <- c("without","launch_grouped","launch_ungrouped","pass_grouped","pass_ungrouped")
#--------------------------------------------------------------------------

#--------------------------------------------------
# compute mean pse value and confidence intervals
c1$cond <-  as.factor(paste(as.integer(round(c1$eve*100)),as.integer(c1$ada),as.integer(c1$context)))
c1_reduced <- c1[,c("answer","cond")]
c1_reduced <- unstack(c1_reduced)

ci_cm <- cm.ci(data.frame=c1_reduced,conf.level=2*(pnorm(1.00,0,1)-0.5),difference=TRUE)

c2$upper <- ci_cm[c(1:10,21:70,11:20),2]
c2$lower <- ci_cm[c(1:10,21:70,11:20),1]

outpred$upper <- NaN
outpred$lower <- NaN
#------------------------------------------------
# add grouping to c2 and outpred

c2 <- c2 %>%
  mutate(grouping = case_when(
    context == 1 ~ "grouped", # not technically correct 
    context == 2 ~ "grouped",
    context == 3 ~ "ungrouped",
    context == 4 ~ "grouped",
    context == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))

outpred <- outpred %>%
  mutate(grouping = case_when(
    context == 1 ~ "grouped", # not technically correct 
    context == 2 ~ "grouped",
    context == 3 ~ "ungrouped",
    context == 4 ~ "grouped",
    context == 5 ~ "ungrouped",
    .default = NA
  )) %>%
  mutate(grouping = as.factor(grouping))

#--------------------------------------------------------------------------
fig <- ggplot(c2,aes(x=eve,y=answer,ymin=lower,ymax=upper,colour=contextfac, linetype = grouping))+facet_wrap(.~adafac,ncol=1)
fig <- fig + scale_colour_manual(values=mycol1)
fig <- fig + scale_fill_manual(values=mycol1)
fig <- fig + scale_x_continuous(limits=c(0,1),breaks=c(0,0.25,0.5,0.75,1))
fig <- fig + scale_y_continuous(limits=c(-0.015,1.01))#,expand = expand_scale(mult=0))
fig <- fig + mytheme
fig <- fig + ylab("Proportion launch reports") + xlab("Disk overlap [proportion]")
fig <- fig + theme(plot.background=element_rect(fill = "transparent",colour = NA)) 
fig <- fig + geom_line(data=outpred,size=0.5)
fig <- fig + scale_linetype_manual(values = c("ungrouped" = "dashed","grouped" = "solid"))
fig <- fig + geom_linerange(size=0.5, linetype = "solid")
fig <- fig + geom_point(shape = 16, size=2)
#--------------------------------------------------------------------------
